package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.TeamEntities;
import sync.works.row_mappers.TeamEntitiesRowMapper;

public class TeamEntitiesRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("userId")).thenReturn(1);
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("lastName")).thenReturn("Doe");
        when(resultSet.getString("employeeId")).thenReturn("EMP001");
        when(resultSet.getInt("role")).thenReturn(2);
        when(resultSet.getString("domain")).thenReturn("IT");

        // Create instance of RowMapper
        TeamEntitiesRowMapper rowMapper = new TeamEntitiesRowMapper();

        // Call the mapRow method
        TeamEntities teamEntities = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, teamEntities.getUserId());
        assertEquals("John", teamEntities.getFirstName());
        assertEquals("Doe", teamEntities.getLastName());
        assertEquals("EMP001", teamEntities.getEmployeeId());
        assertEquals(2, teamEntities.getRole());
        assertEquals("IT", teamEntities.getDomain());
    }
}
