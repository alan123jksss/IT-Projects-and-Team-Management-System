package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.TeamMembersDetails;
import sync.works.row_mappers.TeamMemberRowMapper;

public class TeamMemberRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("userId")).thenReturn(1);
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("lastName")).thenReturn("Doe");
        when(resultSet.getString("employeeId")).thenReturn("EMP001");
        when(resultSet.getInt("role")).thenReturn(2);
        when(resultSet.getString("domain")).thenReturn("IT");
        when(resultSet.getString("gender")).thenReturn("Male");
        when(resultSet.getString("ProjectName")).thenReturn("Project X");

        // Create instance of RowMapper
        TeamMemberRowMapper rowMapper = new TeamMemberRowMapper();

        // Call the mapRow method
        TeamMembersDetails teamMembersDetails = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, teamMembersDetails.getUserId());
        assertEquals("John", teamMembersDetails.getFirstName());
        assertEquals("Doe", teamMembersDetails.getLastName());
        assertEquals("EMP001", teamMembersDetails.getEmployeeId());
        assertEquals(2, teamMembersDetails.getRole());
        assertEquals("IT", teamMembersDetails.getDomain());
        assertEquals("Male", teamMembersDetails.getGender());
        assertEquals("Project X", teamMembersDetails.getProjectName());
    }
}
