package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.ProjectFullTable;
import sync.works.row_mappers.TeamNameCreationRowMapper;

public class TeamNameCreationRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("ProjectId")).thenReturn(1);
        when(resultSet.getString("ProjectName")).thenReturn("TestProject");
        when(resultSet.getString("ProjectTeamName")).thenReturn("TestTeam");

        // Create instance of RowMapper
        TeamNameCreationRowMapper rowMapper = new TeamNameCreationRowMapper();

        // Call the mapRow method
        ProjectFullTable projectFullTable = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, projectFullTable.getProjId());
        assertEquals("TestProject", projectFullTable.getProjName());
        assertEquals("TestTeam", projectFullTable.getProjTeamName());
    }
}
