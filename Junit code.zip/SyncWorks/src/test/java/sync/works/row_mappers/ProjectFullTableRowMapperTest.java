package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.ProjectFullTable;
import sync.works.row_mappers.ProjectFullTableRowMapper;

public class ProjectFullTableRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("ProjectId")).thenReturn(1);
        when(resultSet.getString("ProjectName")).thenReturn("TestProject");
        when(resultSet.getString("ProjectRequirement")).thenReturn("TestRequirement");
        when(resultSet.getString("ProjectPriority")).thenReturn("High");
        when(resultSet.getString("ProjectAssignDate")).thenReturn("2024-02-16");
        when(resultSet.getString("ProjectEndDate")).thenReturn("2024-03-16");
        when(resultSet.getString("firstName")).thenReturn("ManagerFirstName");
        when(resultSet.getString("employeeId")).thenReturn("ManagerEmployeeId");
        when(resultSet.getString("ProjectTeamName")).thenReturn("TestTeam");
        when(resultSet.getString("ProjectStatuss")).thenReturn("Completed");
        when(resultSet.getString("ProjectIssues")).thenReturn("No issues");

        // Create instance of RowMapper
        ProjectFullTableRowMapper rowMapper = new ProjectFullTableRowMapper();

        // Call the mapRow method
        ProjectFullTable projectFullTable = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, projectFullTable.getProjId());
        assertEquals("TestProject", projectFullTable.getProjName());
        assertEquals("TestRequirement", projectFullTable.getProjRequirement());
        assertEquals("High", projectFullTable.getProjPriority());
        assertEquals("2024-02-16", projectFullTable.getProjAssignDate());
        assertEquals("2024-03-16", projectFullTable.getProjEndDate());
        assertEquals("ManagerFirstName", projectFullTable.getManagerName());
        assertEquals("ManagerEmployeeId", projectFullTable.getManagerEmployeeId());
        assertEquals("TestTeam", projectFullTable.getProjTeamName());
        assertEquals("Completed", projectFullTable.getProjStatus());
        assertEquals("No issues", projectFullTable.getProjIssues());
    }
}           
