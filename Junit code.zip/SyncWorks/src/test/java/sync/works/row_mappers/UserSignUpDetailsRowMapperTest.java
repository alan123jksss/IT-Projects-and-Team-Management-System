package sync.works.row_mappers;
import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.UserSignUpDetails;
import sync.works.row_mappers.UserSignUpDetailsRowMapper;

public class UserSignUpDetailsRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("lastName")).thenReturn("Doe");
        when(resultSet.getString("employeeId")).thenReturn("EMP123");
        when(resultSet.getString("mobileNo")).thenReturn("1234567890");
        when(resultSet.getString("gender")).thenReturn("Male");

        // Create instance of RowMapper
        UserSignUpDetailsRowMapper rowMapper = new UserSignUpDetailsRowMapper();

        // Call the mapRow method
        UserSignUpDetails userDetails = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals("John", userDetails.getFirstName());
        assertEquals("Doe", userDetails.getLastName());
        assertEquals("EMP123", userDetails.getEmployeeId());
        assertEquals("1234567890", userDetails.getMobileNo());
        assertEquals("Male", userDetails.getGender());
    }
}
