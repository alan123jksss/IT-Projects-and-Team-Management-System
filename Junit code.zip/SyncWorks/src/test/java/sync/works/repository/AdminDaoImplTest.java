package sync.works.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ListOfUsers;
import sync.works.row_mappers.ListOfUsersRowMapper;

@ExtendWith(MockitoExtension.class)
class AdminDaoImplTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private AdminDaoImpl adminDao;

    @BeforeEach
    void setUp() {
        adminDao = new AdminDaoImpl();
        adminDao.setJdbcTemplate(jdbcTemplate);
    }

    @Test
    void testDomainList() {
        // Given
        String domainName = "TestDomain";

        // When
        when(jdbcTemplate.update(any(String.class), any(String.class))).thenReturn(1);
        int result = adminDao.domainList(domainName);

        // Then
        assertEquals(1, result);
        verify(jdbcTemplate).update(any(String.class), any(String.class));
    }

    @Test
    void testTotalOpenProjectsCount() {
        // Given
        int expectedCount = 5;

        // When
        when(jdbcTemplate.queryForObject(any(String.class), any(Class.class))).thenReturn(expectedCount);
        int result = adminDao.totalOpenProjectsCount();

        // Then
        assertEquals(expectedCount, result);
        verify(jdbcTemplate).queryForObject(any(String.class), any(Class.class));
    }

    @Test
    void testGetAllManagers() {
        // Given
        int role = 2;
        List<ListOfUsers> expectedManagers = Arrays.asList(
                new ListOfUsers(6, "John", "Doe", "123", "HMS", "Manager", true)
        );

        // Stubbing the jdbcTemplate.query method
        when(jdbcTemplate.query(anyString(), any(RowMapper.class), eq(role)))
                .thenReturn(expectedManagers);

        // When
        List<ListOfUsers> actualManagers = adminDao.getAllManagers(role);

        // Then
        assertEquals(expectedManagers, actualManagers);
    }
}
