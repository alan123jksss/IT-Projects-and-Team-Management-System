package sync.works.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import sync.works.entities.UserLoginDetails;
import sync.works.entities.UserSignUpDetails;
import sync.works.repository.UserDaoImpl;
import sync.works.row_mappers.ForgotPasswordRowMapper;
import sync.works.row_mappers.LoginRowMapper;
import sync.works.utils.PasswordUtils;

public class UserDaoImplTest {

    private UserDaoImpl userDao;
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void setup() {
        // Mock JdbcTemplate
        jdbcTemplate = mock(JdbcTemplate.class);
        userDao = new UserDaoImpl();
        userDao.setJdbcTemplate(jdbcTemplate);
    }

    @Test
    public void testRegisterUser() {
        // Mock user data
        UserSignUpDetails user = new UserSignUpDetails();
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmployeeId("12345");
        user.setMobileNo("1234567890");
        user.setPassword("password");
        user.setRole(1);
        user.setDomain("example.com");
        user.setGender("Male");
        user.setStatus(true);
        user.setSecurityQuestion("What's your pet's name?");
        user.setAnswer("Fluffy");

        // Stubbing the PasswordUtils
        String pwdSalt = "salt";
        String pwdHash = "hashed_password";
        when(PasswordUtils.generatePasswordSalt(10)).thenReturn(pwdSalt);
        when(PasswordUtils.generatePasswordHash(pwdSalt + user.getPassword())).thenReturn(pwdHash);

        // Stubbing the JdbcTemplate update method
        when(jdbcTemplate.update(
                "INSERT INTO sync_works.user (`firstName`, `lastName`, `employeeId`, `mobileNo`, `pwdSalt`, `pwdHash`, `role`, `domain`, `gender`, `status`, `securityQuestion`, `answer`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                user.getFirstName(), user.getLastName(), user.getEmployeeId(), user.getMobileNo(), pwdSalt, pwdHash, user.getRole(),
                user.getDomain(), user.getGender(), user.isStatus(), user.getSecurityQuestion(), user.getAnswer()))
                .thenReturn(1);

        // Testing the method
        int result = userDao.registerUser(user);
        assertEquals(1, result);
    }

    @Test
    public void testGetLoginDetails() {
        // Mock user data
        String employeeId = "12345";
        UserLoginDetails expectedUserLoginDetails = new UserLoginDetails();
        expectedUserLoginDetails.setEmployeeId(employeeId);

        // Stubbing the JdbcTemplate queryForObject method
        when(jdbcTemplate.queryForObject(
                "SELECT * FROM user WHERE employeeId = ?", new LoginRowMapper(), employeeId))
                .thenReturn(expectedUserLoginDetails);

        // Testing the method
        UserLoginDetails result = userDao.getLoginDetails(employeeId);
        assertEquals(expectedUserLoginDetails, result);
    }


    @Test
    public void testGetSecurityDetails() {
        // Mock user data
        String employeeId = "12345";
        UserSignUpDetails expectedUserSignUpDetails = new UserSignUpDetails();
        expectedUserSignUpDetails.setEmployeeId(employeeId);

        // Stubbing the JdbcTemplate queryForObject method with any() argument
        when(jdbcTemplate.queryForObject(
                "SELECT securityQuestion, answer FROM user WHERE employeeId = ?", new ForgotPasswordRowMapper(), employeeId))
                .thenReturn(expectedUserSignUpDetails);

        // Testing the method
        UserSignUpDetails result = userDao.getSecurityDetails(employeeId);
        assertEquals(expectedUserSignUpDetails, result);
    }


    @Test
    public void testUpdatePassword() {
        // Mock user data
        String employeeId = "12345";
        String newPassword = "new_password";

        // Stubbing the PasswordUtils
        String newPwdSalt = "new_salt";
        String newPwdHash = "new_hashed_password";
        when(PasswordUtils.generatePasswordSalt(10)).thenReturn(newPwdSalt);
        when(PasswordUtils.generatePasswordHash(newPwdSalt + newPassword)).thenReturn(newPwdHash);

        // Testing the method
        userDao.updatePassword(employeeId, newPassword);
        verify(jdbcTemplate).update(
                "UPDATE user SET pwdHash = ?, pwdSalt = ? WHERE employeeId = ?", newPwdHash, newPwdSalt, employeeId);
    }

    @Test
    public void testGetOneUser() {
        // Mock user data
        String employeeId = "12345";
        UserLoginDetails expectedUserLoginDetails = new UserLoginDetails();
        expectedUserLoginDetails.setEmployeeId(employeeId);

        // Stubbing the JdbcTemplate queryForObject method
        when(jdbcTemplate.queryForObject(
                "SELECT * FROM user WHERE employeeId = ?", new LoginRowMapper(), employeeId))
                .thenReturn(expectedUserLoginDetails);

        // Testing the method
        UserLoginDetails result = userDao.getOneUser(employeeId);
        assertEquals(expectedUserLoginDetails, result);
    }
}
