package sync.works.row_mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.EmployeeProjectDetails;

public class EmployeeProjectRowMapper implements RowMapper<EmployeeProjectDetails> {

	@Override
	public EmployeeProjectDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		EmployeeProjectDetails employeeProDetails = new EmployeeProjectDetails();	
		
		employeeProDetails.setProjId(rs.getInt("ProjectId"));
		employeeProDetails.setProjName(rs.getString("ProjectName"));
		employeeProDetails.setProjRequirement(rs.getString("ProjectRequirement"));
		employeeProDetails.setProjPriority(rs.getString("ProjectPriority"));
		employeeProDetails.setProjAssignDate(rs.getString("ProjectAssignDate"));
		employeeProDetails.setProjEndDate(rs.getString("ProjectEndDate"));
		employeeProDetails.setUserId(rs.getInt("userId"));
		employeeProDetails.setTeamId(rs.getInt("teamId"));
		employeeProDetails.setTeamName(rs.getString("teamName"));
		
		
		return employeeProDetails;
	}

}
