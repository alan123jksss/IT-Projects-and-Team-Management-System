package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ProjectEntities;


public class HighPriorityProjectsRowMapper implements RowMapper<ProjectEntities> {

	@Override
	public ProjectEntities mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		 ProjectEntities project = new ProjectEntities();
		 project.setProjId(rs.getInt("ProjectId"));
         project.setProjName(rs.getString("ProjectName"));         
         project.setProjAssignDate(rs.getString("ProjectAssignDate"));
         project.setProjEndDate(rs.getString("ProjectEndDate"));
         // Set other properties as needed
         return project;
     }

 }