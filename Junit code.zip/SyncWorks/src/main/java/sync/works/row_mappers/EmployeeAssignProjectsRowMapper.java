package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ProjectFullTable;
import sync.works.entities.UserSignUpDetails;


public class EmployeeAssignProjectsRowMapper implements RowMapper<ProjectFullTable> {

	@Override
	public ProjectFullTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ProjectFullTable employeeAssignedProjects = new ProjectFullTable();
		
		employeeAssignedProjects.setProjId(rs.getInt("ProjectId"));
		employeeAssignedProjects.setProjName(rs.getString("ProjectName"));
		employeeAssignedProjects.setProjRequirement(rs.getString("ProjectRequirement"));
		employeeAssignedProjects.setProjPriority(rs.getString("ProjectPriority"));
		employeeAssignedProjects.setProjAssignDate(rs.getString("ProjectAssignDate"));
		employeeAssignedProjects.setProjEndDate(rs.getString("ProjectEndDate"));
		employeeAssignedProjects.setManagerName(rs.getString("firstName"));
		employeeAssignedProjects.setProjTeamName(rs.getString("teamName"));
		employeeAssignedProjects.setProjStatus(rs.getString("projectStatus"));
		employeeAssignedProjects.setProjIssues(rs.getString("issues"));
	
		return employeeAssignedProjects;
	}

}
