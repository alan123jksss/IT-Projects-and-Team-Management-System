package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.TeamEntities;

public class TeamEntitiesRowMapper implements RowMapper<TeamEntities> {

	@Override
	public TeamEntities mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		TeamEntities teamEntities = new TeamEntities();
		
		teamEntities.setUserId(rs.getInt("userId"));
		teamEntities.setFirstName(rs.getString("firstName"));
		teamEntities.setLastName(rs.getString("lastName"));
		teamEntities.setEmployeeId(rs.getString("employeeId"));
		teamEntities.setRole(rs.getInt("role"));
		teamEntities.setDomain(rs.getString("domain"));
		
		
        return teamEntities;
    }
	
		

}
