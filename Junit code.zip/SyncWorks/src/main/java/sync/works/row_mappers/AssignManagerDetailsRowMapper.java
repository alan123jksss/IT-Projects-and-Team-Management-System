package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import sync.works.entities.UserSignUpDetails;


public class AssignManagerDetailsRowMapper implements RowMapper<UserSignUpDetails> {

	@Override
	public UserSignUpDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		UserSignUpDetails listOfUser = new UserSignUpDetails();
				
		listOfUser.setFirstName(rs.getString("firstName"));				
		listOfUser.setEmployeeId(rs.getString("employeeId"));

		return listOfUser;
	
	}

}
