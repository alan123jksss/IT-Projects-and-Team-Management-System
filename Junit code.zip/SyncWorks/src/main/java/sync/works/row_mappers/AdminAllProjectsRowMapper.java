package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ProjectEntities;


public class AdminAllProjectsRowMapper implements RowMapper<ProjectEntities> {

	@Override
	public ProjectEntities mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ProjectEntities project = new ProjectEntities();
		 
		 project.setProjId(rs.getInt("ProjectId"));
		 project.setFirstName(rs.getString("firstName"));
		 project.setLastName(rs.getString("lastName"));
		 project.setDomain(rs.getString("domain"));
		 project.setEmployeeId(rs.getString("employeeId"));
		 project.setRole(rs.getInt("role"));
        project.setProjName(rs.getString("ProjectName"));
        project.setProjRequirement(rs.getString("ProjectRequirement"));
        project.setProjPriority(rs.getString("ProjectPriority"));
        project.setProjAssignDate(rs.getString("ProjectAssignDate"));
        project.setProjEndDate(rs.getString("ProjectEndDate"));
        // Set other properties as needed
        return project;
    }
 }