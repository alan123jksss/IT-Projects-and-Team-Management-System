package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ProjectFullTable;
import sync.works.entities.UserSignUpDetails;


public class ProjectFullTableRowMapper implements RowMapper<ProjectFullTable> {

	@Override
	public ProjectFullTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ProjectFullTable listOfFullProjTable = new ProjectFullTable();
		
		listOfFullProjTable.setProjId(rs.getInt("ProjectId"));
		listOfFullProjTable.setProjName(rs.getString("ProjectName"));
		listOfFullProjTable.setProjRequirement(rs.getString("ProjectRequirement"));
		listOfFullProjTable.setProjPriority(rs.getString("ProjectPriority"));
		listOfFullProjTable.setProjAssignDate(rs.getString("ProjectAssignDate"));
		listOfFullProjTable.setProjEndDate(rs.getString("ProjectEndDate"));
		listOfFullProjTable.setManagerName(rs.getString("firstName"));
		listOfFullProjTable.setManagerEmployeeId(rs.getString("employeeId"));
		listOfFullProjTable.setProjTeamName(rs.getString("ProjectTeamName"));
		listOfFullProjTable.setProjStatus(rs.getString("ProjectStatuss"));
		listOfFullProjTable.setProjIssues(rs.getString("ProjectIssues"));
	
		return listOfFullProjTable;
	}
	
}