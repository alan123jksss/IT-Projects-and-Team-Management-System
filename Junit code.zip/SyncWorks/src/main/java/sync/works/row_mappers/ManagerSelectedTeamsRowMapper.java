package sync.works.row_mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ManagerSelectedTeams;

public class ManagerSelectedTeamsRowMapper implements RowMapper<ManagerSelectedTeams> {

	@Override
	public ManagerSelectedTeams mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ManagerSelectedTeams teams = new ManagerSelectedTeams();
		
		teams.setTeamName(rs.getString("teamName"));
		teams.setFirstName(rs.getString("firstName"));
		teams.setEmployeeId(rs.getString("employeeId"));
		teams.setProjectName(rs.getString("ProjectName"));
		
		
		
		return teams;
	}

}