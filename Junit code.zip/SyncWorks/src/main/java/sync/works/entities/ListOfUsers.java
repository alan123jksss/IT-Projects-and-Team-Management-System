package sync.works.entities;

public class ListOfUsers {
	private int id;
	private String firstName;
	private String lastName;
	private String employeeId;
	private String domain;
	private String role;
	private boolean status;
	public ListOfUsers() {
		super();
		
	}
	
	public ListOfUsers(int id, String firstName, String lastName, String employeeId, String domain, String role,
			boolean status) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.domain = domain;
		this.role = role;
		this.status = status;
	}

	public ListOfUsers(String firstName, String lastName, String employeeId, String domain, String role,
			boolean status) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.domain = domain;
		this.role = role;
		this.status = status;
	}
	public ListOfUsers(String employeeId, boolean status) {
		super();
		this.employeeId = employeeId;
		this.status = status;
	}
	
	


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ListOfUsers [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", employeeId="
				+ employeeId + ", domain=" + domain + ", role=" + role + ", status=" + status + "]";
	}
	
	
	
}
