package sync.works.entities;

public class ManagerSelectedTeams {
	
	private String teamName;
	private String firstName;
	private String employeeId;
	private String projectName;
	public ManagerSelectedTeams() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ManagerSelectedTeams(String teamName, String firstName, String employeeId, String projectName) {
		super();
		this.teamName = teamName;
		this.firstName = firstName;
		this.employeeId = employeeId;
		this.projectName = projectName;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	@Override
	public String toString() {
		return "ManagerSelectedTeams [teamName=" + teamName + ", firstName=" + firstName + ", employeeId=" + employeeId
				+ ", projectName=" + projectName + "]";
	}
	
	

}