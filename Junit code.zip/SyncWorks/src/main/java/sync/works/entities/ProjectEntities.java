package sync.works.entities;

public class ProjectEntities {
	
    private String firstName;
    private String lastName;
    private int role;
    private String domain;
    private String employeeId;
	private int   projId;
	private String projName;
	private String projRequirement;
	private String projManager;
	private String projPriority;
	private String projAssignDate;
	private String projEndDate;
	private String projStatus;
	private String projIssues;
	private String projTeamName;
	
	public ProjectEntities() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public ProjectEntities(String firstName, String lastName, int role, String domain, String employeeId, int projId,
			String projName, String projRequirement, String projManager, String projPriority, String projAssignDate,
			String projEndDate, String projStatus, String projIssues, String projTeamName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.domain = domain;
		this.employeeId = employeeId;
		this.projId = projId;
		this.projName = projName;
		this.projRequirement = projRequirement;
		this.projManager = projManager;
		this.projPriority = projPriority;
		this.projAssignDate = projAssignDate;
		this.projEndDate = projEndDate;
		this.projStatus = projStatus;
		this.projIssues = projIssues;
		this.projTeamName = projTeamName;
	}



	public String getProjTeamName() {
		return projTeamName;
	}


	public void setProjTeamName(String projTeamName) {
		this.projTeamName = projTeamName;
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public int getProjId() {
		return projId;
	}

	public void setProjId(int projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public String getProjRequirement() {
		return projRequirement;
	}

	public void setProjRequirement(String projRequirement) {
		this.projRequirement = projRequirement;
	}

	public String getProjManager() {
		return projManager;
	}

	public void setProjManager(String projManager) {
		this.projManager = projManager;
	}

	public String getProjPriority() {
		return projPriority;
	}

	public void setProjPriority(String projPriority) {
		this.projPriority = projPriority;
	}

	public String getProjAssignDate() {
		return projAssignDate;
	}

	public void setProjAssignDate(String projAssignDate) {
		this.projAssignDate = projAssignDate;
	}

	public String getProjEndDate() {
		return projEndDate;
	}

	public void setProjEndDate(String projEndDate) {
		this.projEndDate = projEndDate;
	}
	
	public String getProjStatus() {
		return projStatus;
	}


	public void setProjStatus(String projStatus) {
		this.projStatus = projStatus;
	}


	public String getProjIssues() {
		return projIssues;
	}


	public void setProjIssues(String projIssues) {
		this.projIssues = projIssues;
	}


	@Override
	public String toString() {
		return "ProjectEntities [firstName=" + firstName + ", lastName=" + lastName + ", role=" + role + ", domain="
				+ domain + ", employeeId=" + employeeId + ", projId=" + projId + ", projName=" + projName
				+ ", projRequirement=" + projRequirement + ", projManager=" + projManager + ", projPriority="
				+ projPriority + ", projAssignDate=" + projAssignDate + ", projEndDate=" + projEndDate + ", projStatus="
				+ projStatus + ", projIssues=" + projIssues + ", projTeamName=" + projTeamName + "]";
	}

	

	
	
	
	
	
}
