package sync.works.entities;

public class TeamMembersDetails {
	private int userId;
	private int projectId;
	private String firstName;
	private String lastName;
	private String employeeId;
	private int role;
	private String domain;
	private String gender;
	private String projectName;
	
	public TeamMembersDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TeamMembersDetails(int userId, int projectId, String firstName, String lastName, String employeeId, int role,
			String domain, String gender, String projectName) {
		super();
		this.userId = userId;
		this.projectId = projectId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.role = role;
		this.domain = domain;
		this.gender = gender;
		this.projectName = projectName;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	@Override
	public String toString() {
		return "TeamMembersDetails [userId=" + userId + ", projectId=" + projectId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", employeeId=" + employeeId + ", role=" + role + ", domain=" + domain
				+ ", gender=" + gender + ", projectName=" + projectName + "]";
	}
	
	
	
	

}


