package sync.works.controller;

import java.util.ArrayList;

import java.util.List;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import sync.works.entities.EmployeeProjectDetails;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ManagerSelectedTeams;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamEntities;
import sync.works.entities.UserLoginDetails;
import sync.works.entities.UserSignUpDetails;
import sync.works.repository.AdminDao;
import sync.works.repository.EmployeeDao;
import sync.works.repository.ManagerDao;
import sync.works.repository.UserDao;
import sync.works.utils.PasswordUtils;

@Controller
public class SyncWorksController {
	
	
	@Autowired
	AdminDao adminDao;
	
	@Autowired
	UserDao userDao;
	
	@Autowired
	ManagerDao managerDao;
	
	@Autowired
	EmployeeDao employeeDao;
	
	public static String id;
	public static String domain;
	public static int userId;
	 
	
	@GetMapping("/")
	public String openHomePage() {
		return "home";
	}
	
	@GetMapping("userSignup")
	public String signUp(Model model,HttpSession session) {
		model.addAttribute("user", new UserSignUpDetails());
		List<String> domainList =  adminDao.domainNameList();
		session.setAttribute("domain",domainList);
		return "user_signup";
	}
	
	@GetMapping("forgot_password")
	public String forgotPassword() {
		return "forgot_password";
	}
		
	
	@GetMapping("securityQuestion")
	public String employee_login() {
		return "security_question";
	
	}
//------------Captcha funtion start here--------------------------	
	private String generateCaptchaMethod() {
        // Generate a random string of length 6
        StringBuilder generatedcaptcha = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
        	generatedcaptcha.append((char) (random.nextInt(26) + 'A'));
        }
        return generatedcaptcha.toString();
    }
	
	
	@GetMapping("/user_login")
	public String adminLoginPage(Model model,HttpSession session) {	    
		String generatedCaptcha = generateCaptchaMethod();
	    //model.addAttribute("captcha", generatedCaptcha);
	    session.setAttribute("generatedCaptcha", generatedCaptcha);
	    System.out.println("generatedCaptcha :" + generatedCaptcha);
		return "user_login";
	}
//------------Captcha function Ends here--------------------------

		
//------------Login function start here--------------------------	
	@PostMapping("/userLogin")
	public String userLogin(
			@RequestParam("employeeId") String employeeId, 
			@RequestParam("password") String password, 
			@RequestParam("inputCaptcha") String inputCaptcha,
	        Model model,HttpSession session, UserLoginDetails userLoginDetails) {

		String generatedCaptcha = (String)session.getAttribute("generatedCaptcha");
		System.out.println("inputCaptcha :" + inputCaptcha);
		
		System.out.println("new" + password);
		
		String destination = "";
		id=employeeId;
		System.out.println(id);
		
		try {
		
		UserLoginDetails loginDetailsFromDb = userDao.getLoginDetails(employeeId);
		domain = loginDetailsFromDb.getDomain();
		userId = loginDetailsFromDb.getUserId();
		System.out.println("public" +userId);

		
			// role, status, pwdHash, pwdSalt based on username									
			System.out.println(domain);
						
			
			userLoginDetails = userDao.getLoginDetails(employeeId);
			session.setAttribute("employeeDetails",userLoginDetails );
			

			System.out.println("\n loginDataFromDb : " + loginDetailsFromDb);
			System.out.println(loginDetailsFromDb.isStatus());

			String pwdSaltFromDb = loginDetailsFromDb.getPwdSalt();
			String pwdHashFromDb = loginDetailsFromDb.getPwdHash();
			
			// Newly generated hash
			String newPwd = pwdSaltFromDb + password;
			String newHash = PasswordUtils.generatePasswordHash(newPwd);
			
			if (newHash.equals(pwdHashFromDb)) {
				
				if (!loginDetailsFromDb.isStatus()) {
					//session.getAttribute("captcha");
					model.addAttribute("type", "failure");
					model.addAttribute("message", "Waiting for approval");
					session.setAttribute("generatedCaptcha",generatedCaptcha);
					
					destination = "user_login";
					
				} else if((loginDetailsFromDb.isStatus() && loginDetailsFromDb.getRole()==2)
						&& inputCaptcha.equals(generatedCaptcha))
						{
					
					model.addAttribute("type", "success");
         			model.addAttribute("message", "Login Successful");
         			
         			try {
						List<ProjectEntities> managerAssignedProjects = managerDao.getManagerProjects(id);
						
						session.setAttribute("managerAssignedProjects", managerAssignedProjects);
						
						int totalProjects = managerDao.totalManagerProjects(userId);
						int totalTeams = managerDao.totalManagerTeams(userId);
						int pendingProjects = managerDao.totalPendingProjects(userId);
						int projectIssues = managerDao.totalProjectIssues(userId);
						int highPriorityProject = managerDao.priorityHighProject(userId);
						int pendingEmployeeApproval = managerDao.pendingEmployeeApproval(domain);
						
						session.setAttribute("totalProjects", totalProjects);		    				    		
						session.setAttribute("totalTeams", totalTeams);		    				    		
						session.setAttribute("pendingProjects", pendingProjects);		    				    		
						session.setAttribute("projectIssues", projectIssues);		    				    		
						session.setAttribute("highPriorityProject", highPriorityProject);		    				    		
						session.setAttribute("pendingEmployeeApproval", pendingEmployeeApproval);
					} catch (Exception e) {
						return "manager_dashboard";
						
					}
		    		
					destination = "manager_dashboard";
						
					
				}else if((loginDetailsFromDb.isStatus() && loginDetailsFromDb.getRole()==3)
						&& inputCaptcha.equals(generatedCaptcha))
						{
							
					List<ProjectFullTable> employeeAssignedProjects = employeeDao.employeeAssignedProjects(userLoginDetails.getUserId());
					model.addAttribute("employeeAssignedProjects",employeeAssignedProjects);
					         			  
        			
					return "employee_dashboard";
					
				}
				else if(inputCaptcha.isEmpty()){
		        	 model.addAttribute("type", "failure");
		        	 model.addAttribute("message", "Captcha Cannot be Empty");
		        	 session.setAttribute("generatedCaptcha",generatedCaptcha);
		        	 return "user_login";
		        	 
		        }else if(!inputCaptcha.equals(generatedCaptcha)){
		        	 model.addAttribute("type", "failure");
		        	 model.addAttribute("message", "Captcha Incorrect");
		        	 session.setAttribute("generatedCaptcha",generatedCaptcha);
		        	 return "user_login";
		        	 
		        }else {
		        	int openProjectVariable = adminDao.totalOpenProjectsCount();
		    		int closeProjectVariable = adminDao.totalCloseProjectsCount();
		    		int totalManagerCountVariable = adminDao.totalManagerCount();
		    		int totalEmployeeCountVariable = adminDao.totalEmployeeCount();
		    		int projectIssues = adminDao.totalProjectIssues();
		    		int highPriCount = adminDao.highPriorityProjectsCount();
		    		int mediumPriCount = adminDao.mediumPriorityProjectsCount();
		    		int lowPriCount = adminDao.LowPriorityProjectsCount();
		    		
		    		session.setAttribute("NumberOfOpenProject",openProjectVariable);
		    		session.setAttribute("NumberOfCloseProject",closeProjectVariable);
		    		session.setAttribute("TotalNumberOfManager",totalManagerCountVariable);
		    		session.setAttribute("TotalNumberOfEmployee",totalEmployeeCountVariable);
		    		session.setAttribute("projectIssues", projectIssues);
		    		session.setAttribute("lowPriCount",lowPriCount);
		    		session.setAttribute("mediumPriCount",mediumPriCount);
		    		session.setAttribute("highPriCount",highPriCount);		    			    		
		    		
		    		List<ProjectEntities> highPriorityProjects = adminDao.highPriorityProjects();
		    		session.setAttribute("highPriorityProjects",highPriorityProjects);
		    		
		    		
					destination = "admin_dashboard";			
				}
				
			} else {
				model.addAttribute("type", "failure");
				model.addAttribute("message", "Wrong Password.");
				session.setAttribute("generatedCaptcha",generatedCaptcha);
				destination = "user_login";
			}

		} catch (EmptyResultDataAccessException e) {
			e.printStackTrace();
			model.addAttribute("type", "failure");
			model.addAttribute("message", "Username not found");
			session.setAttribute("generatedCaptcha",generatedCaptcha);
			destination = "user_login";
		}

		return destination;
	}
//------------Login function Ends here--------------------------	
	

//------------Registration function start here--------------------------	
	@PostMapping("/registerUser")
	public String registerUser(@ModelAttribute UserSignUpDetails user, Model model,HttpSession session) {

		String generatedCaptcha = (String)session.getAttribute("generatedCaptcha");
		System.out.println(user);
		
		try {
			int result = userDao.registerUser(user);
			System.out.println(result);

			if (result > 0) {
				model.addAttribute("type", "success");
				model.addAttribute("message", "User Registered Successfuly");
				session.setAttribute("generatedCaptcha", generatedCaptcha);
				return "user_login";
			} else {
				model.addAttribute("type", "failure");
				model.addAttribute("message", "User could not be registered");
				return "user_signup";
			}
		} catch (DuplicateKeyException e) {
            e.printStackTrace();
            String message = e.getMessage();           
			
            System.out.println(message);
            
			if(message.contains("mobileNo")) {
				model.addAttribute("type", "failure");
	            model.addAttribute("message","Duplicate Employee Id Or Contact Number");
	            return "user_signup";		
			}else if(message.contains("employeeId")) {
				model.addAttribute("type", "failure");
	            model.addAttribute("message","Duplicate Employee Id ");
	            return "user_signup";
			}else {
				model.addAttribute("type", "failure");
	            model.addAttribute("message","Enter Valid Input ");
	            return "user_signup"; 
			}
			
        	
        } catch (DataAccessException e) {
         }

	return "user_login";
	}
	
	@PostMapping("/createPassword")
    public String createPassword(
            @RequestParam("employeeId") String employeeId,
            @RequestParam("newPassword") String newPassword,
            @RequestParam("confirmPassword") String confirmPassword,
            Model model,HttpSession session) {

		String generatedCaptcha = (String)session.getAttribute("generatedCaptcha");
		
        if (newPassword.equals(confirmPassword)) {
       

            userDao.updatePassword(employeeId, newPassword);
            
            System.out.println(newPassword);
            System.out.println(confirmPassword);

            model.addAttribute("type", "success");
            model.addAttribute("message", "Password updated successfully!");
            session.setAttribute("generatedCaptcha",generatedCaptcha);
            return "user_login"; // Redirect to login page or wherever appropriate
        } else {
            model.addAttribute("type", "failure");
            model.addAttribute("message", "Passwords do not match");
            return "forgot_password";
        }
    }
	
	
//------------Registration function Ends here--------------------------	
	
	
//------------Forget password function Start here--------------------------
	

	@PostMapping("/securityQuestion")
	public String securityQuestion(
			@RequestParam("securityQuestion") String securityQuestion, 
			@RequestParam("securityAnswer") String securityAnswer,
			@RequestParam("employeeId") String employeeId,
			Model model,HttpSession session) {

		String destination = "";

		String generatedCaptcha = (String)session.getAttribute("generatedCaptcha");
		
		try {
			// role, status, pwdHash, pwdSalt based on username
			UserSignUpDetails userDetailsFromDb = userDao.getSecurityDetails(employeeId);

			System.out.println("\n userDetailsFromDb : " + userDetailsFromDb);
			
			System.out.println(securityQuestion);
			System.out.println(securityAnswer);
			
			String securityQuestionFromDb = userDetailsFromDb.getSecurityQuestion();
			System.out.println(securityQuestionFromDb);
			
			String securityAnswerFromDb = userDetailsFromDb.getAnswer();
			System.out.println(securityAnswerFromDb);

			if (securityQuestion.equals(securityQuestionFromDb) && securityAnswer.equals(securityAnswerFromDb)) {
			    model.addAttribute("type", "success");
			    model.addAttribute("message", "Success");
			    destination = "forgot_password"; 
			} else {
			    model.addAttribute("type", "failure");
			    model.addAttribute("message", "Please enter the correct details");
			    destination = "security_question";
			}
						
		} catch (EmptyResultDataAccessException e) {
		    e.printStackTrace();
		    model.addAttribute("type", "failure");
		    model.addAttribute("message", "User Id not found");
		    
		    session.setAttribute("generatedCaptcha",generatedCaptcha);
		    destination = "user_login";
		} catch (Exception e) {
		    e.printStackTrace();
		    model.addAttribute("type", "failure");
		    model.addAttribute("message", "Please enter the correct details");
		    
		    session.setAttribute("generatedCaptcha",generatedCaptcha);
		    destination = "user_login";
		}

		return destination;
}
//------------Forget password function Ends here--------------------------	

	
//------------Admin/Projects function Starts here--------------------------
	
	
	
	@GetMapping("/addDomainPage")
	public String addDomainPage() {		
		return "add_domain_page";
	}
	
	@PostMapping("/addDomain")
	public String addDomain(@RequestParam ("addDomain") String[] addDomains,HttpSession session) {	
		
		
		for(String add:addDomains) {
			adminDao.domainList(add);
		}
		
		int openProjectVariable = adminDao.totalOpenProjectsCount();
		int closeProjectVariable = adminDao.totalCloseProjectsCount();
		int totalManagerCountVariable = adminDao.totalManagerCount();
		int totalEmployeeCountVariable = adminDao.totalEmployeeCount();
		int projectIssues = adminDao.totalProjectIssues();
		int highPriCount = adminDao.highPriorityProjectsCount();
		int mediumPriCount = adminDao.mediumPriorityProjectsCount();
		int lowPriCount = adminDao.LowPriorityProjectsCount();
		
		session.setAttribute("NumberOfOpenProject",openProjectVariable);
		session.setAttribute("NumberOfCloseProject",closeProjectVariable);
		session.setAttribute("TotalNumberOfManager",totalManagerCountVariable);
		session.setAttribute("TotalNumberOfEmployee",totalEmployeeCountVariable);
		session.setAttribute("projectIssues", projectIssues);
		session.setAttribute("lowPriCount",lowPriCount);
		session.setAttribute("mediumPriCount",mediumPriCount);
		session.setAttribute("highPriCount",highPriCount);		    			    		
		
		List<ProjectEntities> highPriorityProjects = adminDao.highPriorityProjects();
		session.setAttribute("highPriorityProjects",highPriorityProjects);
		
		return "admin_dashboard";
	}
		
	
	@GetMapping("/adminProfilePage")
	public String adminProfilePage(HttpSession session,Model model) {		
		List<UserSignUpDetails> amdinProfile =  adminDao.adminProfile();
		session.setAttribute("amdinProfile", amdinProfile);
		model.addAttribute("amdinProfile", amdinProfile);						
		return "admin_profile";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
	    if (session != null && !session.isNew()) {
	        // Invalidate the session only if it's not already invalidated
	        session.invalidate();
	    }
	    // Redirect to the login page
	    return "redirect:/user_login";
	}



	
	@GetMapping("/adminCalender")
	public String adminCalender() {
		return "Calender";
	}
	
	
	@GetMapping("/returnAddprojectForm")
	public String returnAddprojectForm() {
		return "admin_addproject_form";
	}
	
	
	@GetMapping("/adminProjectDashboard")
	public String adminProjectDashboard(Model model,HttpSession session){
		
		
		//show full project table
		List<ProjectFullTable> fullProjectTable = adminDao.projectFullTable();
		System.out.println("projects"+fullProjectTable);		
		session.setAttribute("fullProjectTableJsp", fullProjectTable);
					
		//show all managers
		List<ListOfUsers> listOfApproveManagers = adminDao.listOfApproveManagers();
		
		model.addAttribute("listOfApproveManagers",listOfApproveManagers);
		session.setAttribute("listOfApproveManagers", listOfApproveManagers);				
	    return "admin_project_dashboard";
	}
	
		//Assign Manager
		@PostMapping("/assignManager")
		public String assignManager(@RequestParam("firstName") String firstName,
	            					@RequestParam("projectId") int projectId,
	            					Model model,HttpSession session)  {
				
				System.out.println("this is error checking");
				
				if(firstName.equals("")) {
					System.out.println("Name is null");
				}
			    
			    System.out.println(firstName);
				int empId=adminDao.getEmployeeId(firstName);
				
				adminDao.assignManger(empId,projectId);
				
				//show full table
				List<ProjectFullTable> fullProjectTable = adminDao.projectFullTable();
				
				session.setAttribute("fullProjectTableJsp", fullProjectTable);
				
				//show approve managers 
				List<ListOfUsers> listOfApproveManagers = adminDao.listOfApproveManagers();
				
				session.setAttribute("listOfApproveManagers", listOfApproveManagers);		 	
				return "admin_project_dashboard";
				
			
		}
	
	//Add Projects
	@PostMapping("/adminAddProject")
	public String addProject(@ModelAttribute ProjectEntities projectEntities , Model model,HttpSession session) {		
		
		adminDao.addProject(projectEntities);
		System.out.println("Project List" + projectEntities);
		
		//Show all projects
		List<ProjectFullTable> fullProjectTable = adminDao.projectFullTable();
				
		session.setAttribute("fullProjectTableJsp", fullProjectTable);
		
		//show all managers
		List<ListOfUsers> listOfApproveManagers = adminDao.listOfApproveManagers();
		
		session.setAttribute("listOfApproveManagers", listOfApproveManagers);		
		
		return "admin_project_dashboard";
		
	}
	
	
	@PostMapping("/adminUpdateProject")
	public String adminUpdateProject(@ModelAttribute ProjectEntities projectEntities , Model model,HttpSession session) {
		
		
		adminDao.updateProject(projectEntities);
		System.out.println("Updated Project list" + projectEntities);
		
		//Show all projects
				List<ProjectFullTable> fullProjectTable = adminDao.projectFullTable();
						
				session.setAttribute("fullProjectTableJsp", fullProjectTable);
				
				//show all managers
				List<ListOfUsers> listOfApproveManagers = adminDao.listOfApproveManagers();
				
				session.setAttribute("listOfApproveManagers", listOfApproveManagers);		
		
		
		return "admin_project_dashboard";
	}

	//Delete Project
	@GetMapping("/adminDeleteProject")
	public String getMethodName(@RequestParam ("projectId") int projId, Model model,HttpSession session) {
		
		System.out.println(projId);
		adminDao.deleteProject(projId);
		//Show all projects
				List<ProjectFullTable> fullProjectTable = adminDao.projectFullTable();
						
				session.setAttribute("fullProjectTableJsp", fullProjectTable);
				
				//show all managers
				List<ListOfUsers> listOfApproveManagers = adminDao.listOfApproveManagers();
				
				session.setAttribute("listOfApproveManagers", listOfApproveManagers);	
		
		return "admin_project_dashboard";
	}
	
	
	
	
	
	
//------------Admin/Projects function Ends here--------------------------
	
	
//------------Admin/manager function Starts here--------------------------	
	
	//Show Manager Details
	@GetMapping ("/adminManagerDashboard")
	public String managerDetails( Model model) {

		String destination ="";
		
		List<ListOfUsers> listOfAllManagers = adminDao.getAllManagers(true,2);
		model.addAttribute("listOfAllManagers",listOfAllManagers);
		destination = "admin_manager_dashboard";
		
		return destination;	
	}
	
//------------Admin/manager function Ends here--------------------------	
	
//------------Admin/Approval function Starts here--------------------------
	
	//Show approval dashboard
	@GetMapping("/adminApprovalDashboard")
	public String adminApprovalDashboard(Model model) {
		List<ListOfUsers> listOfManagers = adminDao.getAllManagers(2);
			model.addAttribute("listOfManagers",listOfManagers);
		    
		return "admin_approval_dashboard";
	}
	
	
	//Delete Manager details
	@GetMapping("/deleteManager")
	public String deleteBook(@RequestParam("employeeId") String employeeId, Model model) {
		
		String destination = "";

		int result = adminDao.deleteManagers(employeeId);

		if (result > 0) {
			model.addAttribute("type", "success");
			model.addAttribute("message", "Manager deleted successfully");
		} else {
			model.addAttribute("type", "fail");
			model.addAttribute("message", "Manager can't be deleted");
		}

		List<ListOfUsers> listOfManagers = adminDao.getAllManagers(2);
			model.addAttribute("listOfManagers",listOfManagers);
		    destination = "admin_dashboard";

		return destination;
	}
	
	//Approval Change Status
	@GetMapping("/changeStatus")
	public String changeStatus(@RequestParam("status") boolean status, 
			@RequestParam("employeeId") String employeeId, 
			Model model) {

		boolean newStatus = !status;
		
		int result = adminDao.updateManagers(employeeId, newStatus);
		System.out.println(result);
		
		String destination = "";

		if (result > 0) {
			model.addAttribute("type", "success");
			model.addAttribute("message", "Manager with id : " + employeeId+ " updated successfully");
			destination = "admin_approval_dashboard";

					} else {
			model.addAttribute("type", "fail");
			model.addAttribute("message", "Manager with id : " + employeeId+  " updation failed");
			destination = "admin_approval_dashboard"; // see tomorrow
		}
		
		List<ListOfUsers> listOfManagers = adminDao.getAllManagers(2);
		model.addAttribute("listOfManagers",listOfManagers);
		destination = "admin_approval_dashboard";

		return destination;

	}
	
//------------Admin/Approval function Ends here--------------------------	
	
//------------Admin/Employee function Starts here--------------------------	
	@GetMapping ("/employeeDetails")
	public String employeeDetails( Model model) {

		String destination ="";
		
		List<ListOfUsers> listOfAllEmployees = adminDao.getAllEmployees(3);
		model.addAttribute("listOfAllEmployees",listOfAllEmployees);
		destination = "admin_employee_dashboard";
		
		return destination;	
	}
//------------Admin/Employee function Ends here--------------------------	
	

	
//Return Admin Dashboard	
@GetMapping("/adminDashboard")
public String adminDashboard(HttpSession session) {
	int openProjectVariable = adminDao.totalOpenProjectsCount();
	int closeProjectVariable = adminDao.totalCloseProjectsCount();
	int totalManagerCountVariable = adminDao.totalManagerCount();
	int totalEmployeeCountVariable = adminDao.totalEmployeeCount();
	int projectIssues = adminDao.totalProjectIssues();
	int highPriCount = adminDao.highPriorityProjectsCount();
	int mediumPriCount = adminDao.mediumPriorityProjectsCount();
	int lowPriCount = adminDao.LowPriorityProjectsCount();
	
	session.setAttribute("NumberOfOpenProject",openProjectVariable);
	session.setAttribute("NumberOfCloseProject",closeProjectVariable);
	session.setAttribute("TotalNumberOfManager",totalManagerCountVariable);
	session.setAttribute("TotalNumberOfEmployee",totalEmployeeCountVariable);
	session.setAttribute("projectIssues", projectIssues);
	session.setAttribute("lowPriCount",lowPriCount);
	session.setAttribute("mediumPriCount",mediumPriCount);
	session.setAttribute("highPriCount",highPriCount);
	
	
	
	List<ProjectEntities> highPriorityProjects = adminDao.highPriorityProjects();
	session.setAttribute("highPriorityProjects",highPriorityProjects);	
    return "admin_dashboard";
}



//-------------Manager Dashboard ----------------
@GetMapping("/managerDashboard")
public String managerDashboard(Model model) {
	
	List<ProjectEntities> managerAssignedProjects = managerDao.getManagerProjects(id);
		
		model.addAttribute("managerAssignedProjects",managerAssignedProjects);
		return "manager_dashboard";
}


@GetMapping("/listOfEmployeeDetails")
public String approvedEmployeeDetails(Model model) {
	List<ListOfUsers> listOfAllEmployees = managerDao.getApprovedEmployees(3, domain);
	model.addAttribute("listOfAllEmployees",listOfAllEmployees);
	return "manager_employee_dashboard";
	
}

@GetMapping("/deleteEmployee")
public String deleteEmployee(@RequestParam("employeeId") String employeeId, Model model) {

	int result = managerDao.deleteEmployee(employeeId);
	String destination = "";

	if (result > 0) {
		model.addAttribute("type", "success");
		model.addAttribute("message", "Employee deleted successfully");
	} else {
		model.addAttribute("type", "fail");
		model.addAttribute("message", "Employee can't be deleted");
	}

	List<ListOfUsers> listOfEmployees = managerDao.getAllEmployees(3, domain);
		model.addAttribute("listOfEmployees",listOfEmployees);
		destination = "admin_dashboard";

	return "admin_dashboard";
}

//delete employee method ends here//


//update employee status starts here//

@GetMapping("/changeStatusOfEmployee")
public String changeStatusOfEmployee(@RequestParam("status") boolean status, 
		@RequestParam("employeeId") String employeeId, 
		Model model) {

	
	boolean newStatus = !status;
	
	int result = managerDao.updateEmployee(employeeId, newStatus);
	System.out.println(result);
	

	String destination = "";

	if (result > 0) {
		model.addAttribute("type", "success");
		model.addAttribute("message", "Manager with id : " +employeeId+ " updated successfully");

				} else {
		model.addAttribute("type", "fail");
		model.addAttribute("message", "Manager with id : " +employeeId+  " updation failed");
		destination = "manager_approval_dashboard"; // see tomorrow
	}
	
	List<ListOfUsers> listOfEmployees = managerDao.getAllEmployees(3, domain);
	model.addAttribute("listOfEmployees",listOfEmployees);
	destination = "manager_approval_dashboard";

	return destination;

}

//update employee status starts here//



//employee approval by manager starts here//
@GetMapping("/managerApprovalDashboard")
public String managerApprovalDashboard(Model model) {
	List<ListOfUsers> listOfEmployees = managerDao.getAllEmployees(3,domain);
		model.addAttribute("listOfEmployees",listOfEmployees);
	    
	return "manager_approval_dashboard";
}


//employee approval by manager ends here//



//approved employees list starts here
@GetMapping ("/aprrovedEmployeeDetails")
public String aprrovedEmployeeDetails( Model model) {

	String destination ="";
	
	List<ListOfUsers> listOfAllEmployees = managerDao.getApprovedEmployees(3, domain);
	model.addAttribute("listOfAllEmployees",listOfAllEmployees);
	destination = "manager_employee_dashboard";
	
	return destination;	
}
//approved employees list ends here


//Projects visible to manager starts here
//@GetMapping ("/getManagerProjects")
//
//public String getManagerProjects(Model model) {
//	String destination = "";	
//	
//	List<ProjectEntities> listOfProjects = managerDao.getManagerProjects(id);
//	
//	
//	model.addAttribute("listOfProjects",listOfProjects);
//	destination = "manager_assigned_projects";
//	
//	return destination;
//	
//}

@RequestMapping(value = "/choosePath", method = {RequestMethod.GET, RequestMethod.POST})
public String choosePath(
                         @RequestParam("projectId") int projectId,
                         @RequestParam("userId") int userId,
                         Model model) {

    TeamEntities teamEntities = new TeamEntities();

    
    teamEntities.setUserId(userId);
    teamEntities.setProjectId(projectId);
   
    System.out.println(userId);
    System.out.println(projectId);

    System.out.println(teamEntities);

    managerDao.createTeam(teamEntities);
     

    List<TeamEntities> listOfAllEmployees = managerDao.teamMembers(domain);
    model.addAttribute("listOfAllEmployees", listOfAllEmployees);

    List<ProjectEntities> listOfProjects = managerDao.getManagerProjects(id);
    model.addAttribute("listOfProjects", listOfProjects);
   
    return "manager_project_assign";
    
}

//Projects visible to manager starts here


@GetMapping("/createTeam")
public String createTeam(Model model) {
	
	List<TeamEntities> listOfAllEmployees = managerDao.teamMembers(domain);
    model.addAttribute("listOfAllEmployees", listOfAllEmployees);
	
	List<ProjectEntities> listOfProjects = managerDao.getManagerProjects(id);
	model.addAttribute("listOfProjects",listOfProjects);
	model.addAttribute("type", "success");
	
	
	
	
	return "manager_project_assign";

}

@GetMapping("/employeeTeamCreation")
public String employeeTeamCreation(Model modelx,HttpSession session) {
	
	List<ProjectFullTable> teamNameCreation = managerDao.teamNameCreation(userId);
	
	System.out.println("Team Name Creation" + teamNameCreation);
	
	session.setAttribute("teamNameCreation",teamNameCreation);
	
	return "manager_team_name_creation";
	
}


@PostMapping("/assignteam")
public String teamNameCreation(@RequestParam("teamName") String teamName,
		@RequestParam("projectId") int projectId,Model model) {
	
	 managerDao.updateTeamName(teamName,projectId);
	
	
	return "manager_team_name_creation";
}

@GetMapping("/managerSelectedTeams")
public String managerSelectedTeams(Model model) {
	List<ManagerSelectedTeams>  managerSelectedTeams= managerDao.ManagerSelectedTeams(userId);
	model.addAttribute("managerSelectedTeams", managerSelectedTeams);
	
	return "manager_selected_teams";
}

//--------------User Profile Starts Here--------------

	@GetMapping("/userProfile")
	public String userProfileDetails(Model model) {
		UserLoginDetails getOneUser = userDao.getOneUser(id);
		
		String role = "";
		if(getOneUser.getRole()==1) {
			role ="Admin";
		}else if(getOneUser.getRole()==2) {
			role ="Manager";
		}else if(getOneUser.getRole()==3) {
			role ="Employee";
		}
		
		model.addAttribute("employeeId" , id);
		model.addAttribute("firstName" , getOneUser.getFirstName());
		model.addAttribute("lastName" , getOneUser.getLastName());
		model.addAttribute("role", role);
		model.addAttribute("domain", getOneUser.getDomain());
		
		System.out.println(getOneUser.getEmployeeId());
		System.out.println(getOneUser.getFirstName());
		System.out.println(getOneUser.getLastName());
		System.out.println(getOneUser.getRole());
		
		return "user_profile";
		
	}

//--------------User Profile Ends Here--------------
	
	
	
}



	

