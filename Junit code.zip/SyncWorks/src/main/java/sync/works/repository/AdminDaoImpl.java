package sync.works.repository;

import java.util.List;





import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.UserSignUpDetails;
import sync.works.row_mappers.AdminAllProjectsRowMapper;
import sync.works.row_mappers.AssignManagerDetailsRowMapper;
import sync.works.row_mappers.HighPriorityProjectsRowMapper;
import sync.works.row_mappers.ListOfUsersRowMapper;
import sync.works.row_mappers.ProjectFullTableRowMapper;
import sync.works.row_mappers.UserSignUpDetailsRowMapper;

@Repository
public class AdminDaoImpl implements AdminDao{
		
		private JdbcTemplate jdbcTemplate;

		public JdbcTemplate getJdbcTemplate() {
			return jdbcTemplate;
		}

		public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
			this.jdbcTemplate = jdbcTemplate;
		}


		//------------Admin/Projects function Starts here--------------------------
		
		//Store Domain
		@Override
		public int domainList(String domainName){
			String INSERT_DOMAIN = "INSERT INTO domain(`domain`) VALUES (?);";
			return jdbcTemplate.update(INSERT_DOMAIN, domainName);
		}
		
		
		//Show admin Details/profile
		@Override
		public List<UserSignUpDetails> adminProfile() {
			String GET_ADMIN_PROFILE = "SELECT firstName, lastName,employeeId,mobileNo,gender FROM user WHERE role = 1;";
        	
			return jdbcTemplate.query(GET_ADMIN_PROFILE, new UserSignUpDetailsRowMapper());
	    }
		
		
		//Show domain Name
		@Override
		public List<String> domainNameList(){
			
			String DOMAIN_NAME_LIST = "SELECT domain FROM domain";
			
			return jdbcTemplate.queryForList(DOMAIN_NAME_LIST,String.class);
		}
		
		
		//High priority projects
		@Override
		public List<ProjectEntities> highPriorityProjects(){ 
		String HIGH_PRIORITY_PROJECTS = "SELECT ProjectId, ProjectName, ProjectAssignDate, ProjectEndDate "
									+ "FROM projects_table WHERE ProjectPriority = 1;";
		
		return jdbcTemplate.query(HIGH_PRIORITY_PROJECTS, new HighPriorityProjectsRowMapper());
				
		}
		//show full project table Dashboard
		@Override
		public List<ProjectFullTable> projectFullTable() {
		String PROJECT_FULL_TABLE = "SELECT p.ProjectId , p.ProjectName ,p.ProjectRequirement,"
									+ "p.ProjectPriority,p.ProjectAssignDate,p.ProjectEndDate, "
									+ "p.ProjectTeamName, p.ProjectStatuss,p.ProjectIssues, "
									+ "u.firstName,u.employeeId FROM projects_table p LEFT JOIN "
									+ "user u ON p.ProjectManagerId = u.userId;";
					
		return jdbcTemplate.query(PROJECT_FULL_TABLE, new ProjectFullTableRowMapper()) ;
		}
		
		//Show all projects 
		@Override
		public List<ProjectEntities> adminAllProjects() {
			String SHOW_ALL_PROJECTS = "SELECT * FROM projects_table";
		    
			List<ProjectEntities> allProjects = jdbcTemplate.query(SHOW_ALL_PROJECTS,new AdminAllProjectsRowMapper());
			return allProjects;
		}
		
		
		
		//Add Project 
		@Override
		public int addProject(ProjectEntities projectEntities) {
			int result=0;
				String ADD_PROJECTS = "INSERT INTO projects_table(`ProjectName`, `ProjectRequirement`, "
						+ "`ProjectPriority`, `ProjectAssignDate`, `ProjectEndDate`) "
						+ "VALUES(?, ? ,?, ?, ?)";
				
			result = jdbcTemplate.update(ADD_PROJECTS,projectEntities.getProjName(),
											        projectEntities.getProjRequirement(),											        
											        projectEntities.getProjPriority(),
											        projectEntities.getProjAssignDate(),
											        projectEntities.getProjEndDate());	
											
			return result;
		}
		
		
		//Update Project
		@Override
		public int updateProject(ProjectEntities projectEntities) {
		    String UPDATE_PROJECT = "UPDATE projects_table SET ProjectName = ?,ProjectRequirement = ?, " +
		                            "ProjectPriority = ?, " +
		                            "ProjectAssignDate = ?, ProjectEndDate = ? " +
		                            "WHERE ProjectId = ?";
		    
		    int result = jdbcTemplate.update(UPDATE_PROJECT,projectEntities.getProjName(),
									        projectEntities.getProjRequirement(),									        
									        projectEntities.getProjPriority(),
									        projectEntities.getProjAssignDate(),
									        projectEntities.getProjEndDate(),
									        projectEntities.getProjId());
									        
		    
		    return result;
		}	
		
		//Delete Project
		@Override
		public int deleteProject(int projectId) {
		    String DELETE_PROJECT = "DELETE FROM projects_table WHERE ProjectId = ?";		    
		    int result = jdbcTemplate.update(DELETE_PROJECT, projectId);
		    
		    return result;
		}
		
		
		//Number Of Open Projects
		@Override
		public int totalOpenProjectsCount() {
			String OPEN_PROJECTS ="SELECT COUNT(*) AS project_count FROM projects_table WHERE ProjectStatuss = 1 ";
			return jdbcTemplate.queryForObject(OPEN_PROJECTS, Integer.class);
		}
		
		//Number Of Close Projects
		@Override
		public int totalCloseProjectsCount() {
			String CLOSE_PROJECTS ="SELECT COUNT(*) AS project_count FROM projects_table WHERE ProjectStatuss = 0 ";
			return jdbcTemplate.queryForObject(CLOSE_PROJECTS, Integer.class);
		}
		
		@Override
		public int totalProjectIssues() {
		    String TOTAL_PROJECT_ISSUES = "SELECT count(ProjectIssues) "
		    		+ "FROM projects_table;";
		    return jdbcTemplate.queryForObject(TOTAL_PROJECT_ISSUES, Integer.class);
		}
		
		//Number Of Manager
		@Override
		public int totalManagerCount() {
			String TOTAL_MANAGER_COUNT = "SELECT COUNT(*) AS manager_count FROM user WHERE role = 2";
			return jdbcTemplate.queryForObject(TOTAL_MANAGER_COUNT, Integer.class);
		}
	
		//Number Of Employee
		@Override
		public int totalEmployeeCount() {
			String TOTAL_EMPLOYEE_COUNT = "SELECT COUNT(*) AS employee_count FROM user WHERE role = 3";
			return jdbcTemplate.queryForObject(TOTAL_EMPLOYEE_COUNT, Integer.class);
		}
		
		//Assign Manager
		@Override
		public void assignManger(int userId, int ProjectId) {
			String ASSIGN_MANAGER = "UPDATE sync_works.projects_table SET ProjectManagerId = ? WHERE (ProjectId = ?);";
									
			jdbcTemplate.update(ASSIGN_MANAGER,userId,ProjectId);
		}
	
		//show assign manager
		@Override
		public List<UserSignUpDetails> showAssignManager() {
		    String SHOW_ASSIGN_MANAGER = "SELECT u.firstName , u.employeeId "
							    		+ "FROM projects_table p LEFT JOIN user u "
							    		+ "ON p.ProjectManagerId = u.userId;";
		    		
		    return jdbcTemplate.query(SHOW_ASSIGN_MANAGER, new AssignManagerDetailsRowMapper());
		}
		
		
		//High priority projects count
			@Override
			public int highPriorityProjectsCount(){ 
			String HIGH_PRIORITY_PROJECTS_COUNT = "SELECT COUNT(*) AS HighPriorityCount "
					+ "FROM projects_table WHERE ProjectPriority = 1;";
				
			return jdbcTemplate.queryForObject(HIGH_PRIORITY_PROJECTS_COUNT, Integer.class);
						
			}
			//medium priority projects count
			@Override
			public int mediumPriorityProjectsCount(){ 
			String MEDIUM_PRIORITY_PROJECTS_COUNT = "SELECT COUNT(*) AS HighPriorityCount "
					+ "FROM projects_table WHERE ProjectPriority = 2;";
				
			return jdbcTemplate.queryForObject(MEDIUM_PRIORITY_PROJECTS_COUNT, Integer.class);
						
			}	
			//Low priority projects count
			@Override
			public int LowPriorityProjectsCount(){ 
			String LOW_PRIORITY_PROJECTS_COUNT = "SELECT COUNT(*) AS HighPriorityCount "
					+ "FROM projects_table WHERE ProjectPriority = 3;";
				
			return jdbcTemplate.queryForObject(LOW_PRIORITY_PROJECTS_COUNT, Integer.class);
						
			}		
			
		
		@Override
		public int getEmployeeId(String firstName) {
			 String GET_USER_ID = "SELECT userId FROM user WHERE firstName = ?;";
			 return jdbcTemplate.queryForObject(GET_USER_ID, new Object[] {firstName},Integer.class);
			 
			 
		}
		
		

				
		
		//------------Admin/Projects function Ends here--------------------------
		
		//------------Admin/Managers function Starts here--------------------------	
			@Override
			public int deleteManagers(String employeeId) {
				String DELETE_MANAGERS = "DELETE FROM user WHERE employeeId = ?";
				return jdbcTemplate.update(DELETE_MANAGERS, employeeId);
			}
			
			//list of all managers 
			@Override
			public List<ListOfUsers> getAllManagers(int role) {
				String GET_ALL_MANAGERS = "SELECT * FROM user WHERE role = ?";
	        	
				return jdbcTemplate.query(GET_ALL_MANAGERS, new ListOfUsersRowMapper(), role);
		    }
			
			//list of approved managers
			@Override
			public List<ListOfUsers> listOfApproveManagers(){
				String GET_APPROVE_MANAGERS = "SELECT * FROM user WHERE role = ? AND status = ?";
				
				return jdbcTemplate.query(GET_APPROVE_MANAGERS, new ListOfUsersRowMapper(),2,1);
				
			}
			
			
			@Override
			public int updateManagers(String employeeId, boolean status) {
				String UPDATE_MANAGERS ="UPDATE user SET status = ? WHERE employeeId =?";
				
				return jdbcTemplate.update(UPDATE_MANAGERS, status, employeeId);
			}
			
			@Override
			public List<ListOfUsers> getAllManagers(boolean status, int role) {
				String GET_ALL_MANAGERS = "SELECT * FROM user WHERE status = ? AND role =?";
				return jdbcTemplate.query(GET_ALL_MANAGERS, new ListOfUsersRowMapper(), status, role);
		}
			
		//------------Admin/Managers function Ends here--------------------------	
		
			
		//------------Admin/Employees function Starts here--------------------------	
			@Override
			public List<ListOfUsers> getAllEmployees(int role) {
				String GET_ALL_EMPLOYEES = "SELECT * FROM user WHERE role =?";
				return jdbcTemplate.query(GET_ALL_EMPLOYEES, new ListOfUsersRowMapper(), role);
		}

			
			
		//------------Admin/Employees function Ends here--------------------------		
			
				
		

	}
