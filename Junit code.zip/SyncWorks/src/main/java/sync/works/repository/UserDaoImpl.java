package sync.works.repository;

import org.springframework.dao.EmptyResultDataAccessException;

import org.springframework.jdbc.core.JdbcTemplate;

import sync.works.entities.UserLoginDetails;
//import sync.works.entities.LoginDetails;
import sync.works.entities.UserSignUpDetails;
import sync.works.row_mappers.ForgotPasswordRowMapper;
import sync.works.row_mappers.LoginRowMapper;
//import sync.works.row_mappers.LoginRowMapper;
import sync.works.utils.PasswordUtils;

public class UserDaoImpl implements UserDao {

    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int registerUser(UserSignUpDetails user) {
    	
        String INSERT_USER = "INSERT INTO sync_works.user "
                + "(`firstName`, `lastName`, `employeeId`, "
                + "`mobileNo`, `pwdSalt`, `pwdHash`, `role`, `domain`, `gender`,`status`,`securityQuestion`,`answer`) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

        String pwdSalt = PasswordUtils.generatePasswordSalt(10);
        String newPwd = pwdSalt + user.getPassword();
        String pwdHash = PasswordUtils.generatePasswordHash(newPwd);
        
        if(user.getRole() == 2) {
			user.setStatus(false);
		} else if(user.getRole()==3) {
			user.setStatus(false);
		}
		else if(user.getRole()==1) {
			user.setStatus(true);
		}
		
		return jdbcTemplate.update(INSERT_USER, user.getFirstName(),user.getLastName(),
				user.getEmployeeId(), user.getMobileNo(), 
				 pwdSalt, pwdHash,user.getRole(), user.getDomain(),user.getGender(), user.isStatus(), user.getSecurityQuestion(), user.getAnswer());
    }

        
    
    @Override
	public UserLoginDetails getLoginDetails(String employeeId) throws EmptyResultDataAccessException {
		String LOGIN_DETAILS = "SELECT * "
				+ "FROM user WHERE employeeId = ?";
		
		UserLoginDetails login = jdbcTemplate.queryForObject(LOGIN_DETAILS, new LoginRowMapper(), employeeId);
		
		System.out.println("\n Login : " + login);
		return login;
	}
    
    
    @Override
   	public UserSignUpDetails getSecurityDetails(String employeeId) throws EmptyResultDataAccessException {
    	String FORGOT_PASSWORD = "SELECT securityQuestion, answer "
    		    + "FROM user WHERE employeeId = ?";

   		
   		UserSignUpDetails forgotPassword = jdbcTemplate.queryForObject(FORGOT_PASSWORD, new ForgotPasswordRowMapper(), employeeId);
   		
   		System.out.println("\n forgotPassword : " + forgotPassword);
   		
   		return forgotPassword;
   	}
    
    @Override
    public void updatePassword(String employeeId, String newPassword) {
        String UPDATE_PASSWORD = "UPDATE user SET pwdHash = ?, pwdSalt = ? WHERE employeeId = ?";
        
        // Generate new password hash and salt using your utils
        String newPwdSalt = PasswordUtils.generatePasswordSalt(10);
        String newPwdHash = PasswordUtils.generatePasswordHash(newPwdSalt + newPassword);
        
        jdbcTemplate.update(UPDATE_PASSWORD, newPwdHash, newPwdSalt, employeeId);
    }
    
    //User Profile details
    @Override    
   	public UserLoginDetails getOneUser(String employeeId) {
   		String GET_ONE_USER = "SELECT * FROM user WHERE employeeId =?";
   		return jdbcTemplate.queryForObject(GET_ONE_USER, new LoginRowMapper(), employeeId);
   }
    
    
    
}


