package sync.works.repository;

import java.util.List;

import sync.works.entities.EmployeeProjectDetails;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamMembersDetails;

public interface EmployeeDao {

	List<ListOfUsers> managerAssigned(String domain);


	List<ProjectFullTable> employeeAssignedProjects(int userId);


	void updateProjectStatus(String projectStatus, String projectId);


	void updateProjectIssues(String projectIssues, String projectId);


	List<TeamMembersDetails> teamMembers(int userId);










}
