package sync.works.repository;

import java.util.List;


import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamEntities;
import sync.works.row_mappers.ListOfUsersRowMapper;
import sync.works.row_mappers.ManagerAssignedProjectsRowMapper;
import sync.works.row_mappers.ManagerSelectedTeamsRowMapper;
import sync.works.row_mappers.TeamEntitiesRowMapper;
import sync.works.row_mappers.TeamNameCreationRowMapper;

@Repository
public class ManagerDaoImpl implements ManagerDao
{
	
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	@Override
	public int deleteEmployee(String employeeId) {
		String DELETE_EMPLOYEES = "DELETE FROM user WHERE employeeId = ?";
		return jdbcTemplate.update(DELETE_EMPLOYEES, employeeId);
	}

	@Override
	public List<ListOfUsers> getAllEmployees(int role, String domain) {
		String GET_ALL_EMPLOYEES = "SELECT * FROM user WHERE role = ? AND domain = ?";
		return jdbcTemplate.query(GET_ALL_EMPLOYEES, new ListOfUsersRowMapper(), role,domain);
}
	
	

	@Override
	public int updateEmployee(String employeeId, boolean status) {
		String UPDATE_EMPLOYEES ="UPDATE user SET status = ? WHERE employeeId =?";
		
		return jdbcTemplate.update(UPDATE_EMPLOYEES, status, employeeId);
	}
	
	@Override
	public List<ListOfUsers> getApprovedEmployees(int role, String domain) {
		String GET_ALL_EMPLOYEES = "SELECT * FROM user WHERE role = ? AND domain = ? AND status = 1 ";
		return jdbcTemplate.query(GET_ALL_EMPLOYEES, new ListOfUsersRowMapper(), role,domain);
	}
	
	@Override
	public List<ProjectEntities> getManagerProjects(String employeeId) {
		String GET_MANAGER_PROJECTS ="SELECT ProjectId , ProjectName, ProjectRequirement, ProjectPriority, "
	    		+ "ProjectAssignDate, ProjectEndDate, ProjectStatuss,ProjectIssues,ProjectTeamName "
	    		+ "FROM projects_table RIGHT JOIN user "
	    		+ "ON projects_table.ProjectManagerId=user.userId WHERE user.employeeId=?;";
	    	

	    return jdbcTemplate.query(GET_MANAGER_PROJECTS, new ManagerAssignedProjectsRowMapper(), employeeId);
	}
	
	@Override
	public int createTeam(TeamEntities teamEntities) {
	    String INSERT_TEAM = "INSERT INTO team_table ( `userId`, `projectId`) VALUES (?, ?)";	    
	    
	        return jdbcTemplate.update(INSERT_TEAM,  
	        		teamEntities.getUserId(), teamEntities.getProjectId());
    }  
	@Override
	public List<TeamEntities> teamMembers(String domain) {
		String GET_TEAM = "SELECT u.`userId`, u.`firstName`, u.`lastName`, u.`employeeId`, u.`domain`, u.`role`\r\n"
				+ "FROM user u\r\n"
				+ "LEFT JOIN team_table t ON u.userId = t.userId\r\n"
				+ "WHERE t.userId IS NULL AND u.role = 3 AND u.domain=? AND u.status = 1;";
		return jdbcTemplate.query(GET_TEAM, new TeamEntitiesRowMapper(),domain);
}
	@Override
	public List<ProjectFullTable> teamNameCreation(int managerId) {
		String TEAM_NAME_CREATION = "SELECT DISTINCT p.ProjectId, p.ProjectName,p.ProjectTeamName, t.teamName "
				+ "FROM projects_table p INNER JOIN team_table t ON p.ProjectId = t.projectId WHERE p.ProjectManagerId = ?;";
				
		return jdbcTemplate.query(TEAM_NAME_CREATION, new TeamNameCreationRowMapper(),managerId);
}
	
	//Update Team Name 
	@Override
	public int updateTeamName(String teamName, int projectId) {
		String UPDATE_TEAM_NAME = "UPDATE projects_table AS pt JOIN team_table AS tt ON pt.ProjectId = tt.projectId SET pt.ProjectTeamName = ?, tt.teamName = ? WHERE pt.ProjectId = ?;";
		
		return jdbcTemplate.update(UPDATE_TEAM_NAME,teamName,teamName,projectId);					
		
	}
	@Override
	public int totalManagerProjects(int userId) {
	    String TOTAL_PROJECT_COUNT = "SELECT COUNT(ProjectName) FROM "
	    		+ "projects_table WHERE ProjectManagerId=?";
	    return jdbcTemplate.queryForObject(TOTAL_PROJECT_COUNT, Integer.class, userId);
	}
	@Override
	public int totalManagerTeams(int managerId) {
	    String TOTAL_TEAM_COUNT = "SELECT Count(DISTINCT t.projectId) "
	    		+ "FROM team_table t INNER JOIN projects_table p "
	    		+ "ON t.projectId = p.ProjectId  WHERE p.ProjectManagerId=?;";
	    return jdbcTemplate.queryForObject(TOTAL_TEAM_COUNT, Integer.class, managerId);
	}
	
	@Override
	public int totalPendingProjects(int managerId) {
	    String TOTAL_PENDING_PROJECTS = "SELECT COUNT(ProjectStatuss) "
	    		+ "FROM projects_table "
	    		+ "WHERE ProjectStatuss = 1 "
	    		+ "AND ProjectManagerId =?;";
	    return jdbcTemplate.queryForObject(TOTAL_PENDING_PROJECTS, Integer.class, managerId);
	}
	@Override
	public int totalProjectIssues(int managerId) {
	    String TOTAL_PROJECT_ISSUES = "SELECT count(ProjectIssues) "
	    		+ "FROM projects_table WHERE  "
	    		+ "ProjectManagerId =?;";
	    return jdbcTemplate.queryForObject(TOTAL_PROJECT_ISSUES, Integer.class, managerId);
	}
	
	@Override
	public int priorityHighProject(int managerId) {
	    String PROJECT_HIGH_PRIORITY = "SELECT count(ProjectPriority) "
	    		+ "FROM projects_table "
	    		+ "WHERE ProjectManagerId =? AND ProjectPriority=1;";
	    return jdbcTemplate.queryForObject(PROJECT_HIGH_PRIORITY, Integer.class, managerId);
	}
	
	@Override
	public int pendingEmployeeApproval(String domain) {
	    String PENDING_EMPLOYEE_APPROVAL = "SELECT count(status) From user WHERE domain=? "
	    		+ "AND status =0;";
	    return jdbcTemplate.queryForObject(PENDING_EMPLOYEE_APPROVAL, Integer.class, domain);
	}
	
	//manager selected teams
	
	@Override
	public List<sync.works.entities.ManagerSelectedTeams> ManagerSelectedTeams(int managerId) {
		String MANAGER_TEAMS = "SELECT t.teamName , u.firstName, u.employeeId ,p.ProjectName "
				+ "FROM team_table t INNER JOIN projects_table p "
				+ "INNER JOIN user u on t.projectId = p.ProjectId AND t.userId=u.userId "
				+ "WHERE p.ProjectManagerId =?;";
			
		return jdbcTemplate.query(MANAGER_TEAMS, new ManagerSelectedTeamsRowMapper(),managerId );
	}
   
	
}
