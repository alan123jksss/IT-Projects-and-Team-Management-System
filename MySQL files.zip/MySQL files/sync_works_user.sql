-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: sync_works
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `employeeId` varchar(30) NOT NULL,
  `mobileNo` varchar(15) NOT NULL,
  `pwdSalt` varchar(50) NOT NULL,
  `pwdHash` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL,
  `domain` varchar(45) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `status` bit(1) NOT NULL,
  `securityQuestion` varchar(50) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `projectStatus` varchar(10) DEFAULT NULL,
  `issues` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `employeeId_UNIQUE` (`employeeId`),
  UNIQUE KEY `mobileNo_UNIQUE` (`mobileNo`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Sync','Works','703376123@genpact.com','1234567898','9dsuZApvW6','02ebb8e93480dcc3d71e','1','BMS','M',_binary '','2','hyderabad',NULL,NULL),(41,'Alan','John','703376234@genpact.com','9878987897','nZYVRfZatv','5594dcb2dd88d0714070','2','HMS','on',_binary '','2','Gudalur',NULL,NULL),(42,'harish','k','703376000@genpact.com','9191928283','9eflG0HWUO','3eada36336db34db4b8d','3','HMS','on',_binary '','2','coimbatore',NULL,NULL),(45,'Pavi','Moni','703376999@genpact.com','9876543456','sjkFVhjBrS','6b84d61b1828790809dc','3','HMS','M',_binary '','2','coimbatore','1','FGHJK'),(46,'Shiva','k','703376345@genpact.com','9876545678','YoQFrT5M9j','2c988d79e4c59bb422d9','2','BMS','M',_binary '\0','2','Gudalur',NULL,NULL),(47,'vicky','y','703376888@genpact.com','9876789876','NqPadygKus','0eb444b064caa84a9a1d','3','HMS','M',_binary '','2','hyderabad',NULL,NULL),(48,'Ganesh','S','703376777@genpact.com','7897654321','uWSdjBL7k8','6194c2febb91993abf4c','3','BMS','M',_binary '\0','2','Gudalur',NULL,NULL),(49,'Shiva','K','703376456@genpact.com','9876785432','JPwyl60SXl','83cc08cddc06bb77dd0d','2','HMS','M',_binary '','2','coimbatore',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-13 12:44:14
