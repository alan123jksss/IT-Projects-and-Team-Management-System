package sync.works.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import sync.works.entities.UserLoginDetails;
import sync.works.entities.UserSignUpDetails;
import sync.works.row_mappers.ForgotPasswordRowMapper;
import sync.works.row_mappers.LoginRowMapper;
import sync.works.utils.PasswordUtils;

public class UserDaoImplTest {

    private UserDaoImpl userDao;
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void setup() {
        // Mock JdbcTemplate
        jdbcTemplate = mock(JdbcTemplate.class);
        userDao = new UserDaoImpl();
        userDao.setJdbcTemplate(jdbcTemplate);
       
    }


    @Test
    public void testGetLoginDetails() {
        // Mock user data
        String employeeId = "12345";
        UserLoginDetails expectedUserLoginDetails = new UserLoginDetails();
        expectedUserLoginDetails.setEmployeeId(employeeId);

        // Stubbing the JdbcTemplate queryForObject method
        when(jdbcTemplate.queryForObject(
                eq("SELECT * FROM user WHERE employeeId = ?"), 
                any(LoginRowMapper.class), 
                eq(employeeId)))
                .thenReturn(expectedUserLoginDetails);

        // Testing the method
        UserLoginDetails result = userDao.getLoginDetails(employeeId);
        assertEquals(expectedUserLoginDetails, result);
    }


    @Test
    public void testGetSecurityDetails() {
        // Mock user data
        String employeeId = "12345";
        UserSignUpDetails expectedUserSignUpDetails = new UserSignUpDetails();
        expectedUserSignUpDetails.setEmployeeId(employeeId);

        // Stubbing the JdbcTemplate queryForObject method with any() argument
        when(jdbcTemplate.queryForObject(
                eq("SELECT securityQuestion, answer FROM user WHERE employeeId = ?"),
                any(ForgotPasswordRowMapper.class),
                eq(employeeId)))
                .thenReturn(expectedUserSignUpDetails);

        // Testing the method
        UserSignUpDetails result = userDao.getSecurityDetails(employeeId);
        assertEquals(expectedUserSignUpDetails, result);
    }



    
}
