package sync.works.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ManagerSelectedTeams;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamEntities;
import sync.works.repository.ManagerDaoImpl;
import sync.works.row_mappers.ListOfUsersRowMapper;
import sync.works.row_mappers.ManagerAssignedProjectsRowMapper;
import sync.works.row_mappers.ManagerSelectedTeamsRowMapper;
import sync.works.row_mappers.TeamEntitiesRowMapper;
import sync.works.row_mappers.TeamNameCreationRowMapper;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class ManagerDaoImplTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private ManagerDaoImpl managerDao;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDeleteEmployee() {
        // Arrange
        String employeeId = "E123";
        int expectedCount = 1;

        when(jdbcTemplate.update(anyString(), eq(employeeId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.deleteEmployee(employeeId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testGetAllEmployees() {
        // Arrange
        int role = 2;
        String domain = "example.com";
        List<ListOfUsers> expectedList = new ArrayList<>();

        when(jdbcTemplate.query(anyString(), any(ListOfUsersRowMapper.class), eq(role), eq(domain)))
                .thenReturn(expectedList);

        // Act
        List<ListOfUsers> actualList = managerDao.getAllEmployees(role, domain);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testUpdateEmployee() {
        // Arrange
        String employeeId = "E123";
        boolean status = true;
        int expectedCount = 1;

        when(jdbcTemplate.update(anyString(), eq(status), eq(employeeId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.updateEmployee(employeeId, status);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testGetApprovedEmployees() {
        // Arrange
        int role = 2;
        String domain = "example.com";
        List<ListOfUsers> expectedList = new ArrayList<>();

        when(jdbcTemplate.query(anyString(), any(ListOfUsersRowMapper.class), eq(role), eq(domain)))
                .thenReturn(expectedList);

        // Act
        List<ListOfUsers> actualList = managerDao.getApprovedEmployees(role, domain);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testGetManagerProjects() {
        // Arrange
        String employeeId = "E123";
        List<ProjectEntities> expectedList = new ArrayList<>();

        when(jdbcTemplate.query(anyString(), any(ManagerAssignedProjectsRowMapper.class), eq(employeeId)))
                .thenReturn(expectedList);

        // Act
        List<ProjectEntities> actualList = managerDao.getManagerProjects(employeeId);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testCreateTeam() {
        // Arrange
        TeamEntities teamEntities = new TeamEntities();
        teamEntities.setUserId(123);
        teamEntities.setProjectId(456);
        int expectedCount = 1;

        when(jdbcTemplate.update(anyString(), eq(teamEntities.getUserId()), eq(teamEntities.getProjectId())))
                .thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.createTeam(teamEntities);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testTeamMembers() {
        // Arrange
        String domain = "example.com";
        List<TeamEntities> expectedList = new ArrayList<>();

        when(jdbcTemplate.query(anyString(), any(TeamEntitiesRowMapper.class), eq(domain)))
                .thenReturn(expectedList);

        // Act
        List<TeamEntities> actualList = managerDao.teamMembers(domain);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testTeamNameCreation() {
        // Arrange
        int managerId = 123;
        List<ProjectFullTable> expectedList = new ArrayList<>();

        when(jdbcTemplate.query(anyString(), any(TeamNameCreationRowMapper.class), eq(managerId)))
                .thenReturn(expectedList);

        // Act
        List<ProjectFullTable> actualList = managerDao.teamNameCreation(managerId);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testUpdateTeamName() {
        // Arrange
        String teamName = "Team A";
        int projectId = 456;
        int expectedCount = 1;

        when(jdbcTemplate.update(anyString(), eq(teamName), eq(teamName), eq(projectId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.updateTeamName(teamName, projectId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testTotalManagerProjects() {
        // Arrange
        int userId = 123;
        int expectedCount = 5;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), eq(userId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.totalManagerProjects(userId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testTotalManagerTeams() {
        // Arrange
        int managerId = 123;
        int expectedCount = 3;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), eq(managerId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.totalManagerTeams(managerId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testTotalPendingProjects() {
        // Arrange
        int managerId = 123;
        int expectedCount = 2;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), eq(managerId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.totalPendingProjects(managerId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testTotalProjectIssues() {
        // Arrange
        int managerId = 123;
        int expectedCount = 4;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), eq(managerId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.totalProjectIssues(managerId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testPriorityHighProject() {
        // Arrange
        int managerId = 123;
        int expectedCount = 6;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), eq(managerId))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.priorityHighProject(managerId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testPendingEmployeeApproval() {
        // Arrange
        String domain = "example.com";
        int expectedCount = 3;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), eq(domain))).thenReturn(expectedCount);

        // Act
        int actualCount = managerDao.pendingEmployeeApproval(domain);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testManagerSelectedTeams() {
        // Arrange
        int managerId = 123;
        List<ManagerSelectedTeams> expectedList = new ArrayList<>();

        when(jdbcTemplate.query(anyString(), any(ManagerSelectedTeamsRowMapper.class), eq(managerId)))
                .thenReturn(expectedList);

        // Act
        List<ManagerSelectedTeams> actualList = managerDao.ManagerSelectedTeams(managerId);

        // Assert
        assertEquals(expectedList, actualList);
    }
}
