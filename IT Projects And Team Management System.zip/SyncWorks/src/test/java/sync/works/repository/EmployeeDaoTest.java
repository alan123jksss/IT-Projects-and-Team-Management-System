package sync.works.repository;

import org.junit.jupiter.api.Test;

import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamMembersDetails;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;

public class EmployeeDaoTest {

    @Test
    public void testManagerAssigned() {
        // Arrange
        EmployeeDao employeeDao = mock(EmployeeDao.class);
        String domain = "example.com";

        // Act
        List<ListOfUsers> result = employeeDao.managerAssigned(domain);

        // Assert
        // Add assertions as needed
    }

    @Test
    public void testEmployeeAssignedProjects() {
        // Arrange
        EmployeeDao employeeDao = mock(EmployeeDao.class);
        int userId = 123;

        // Act
        List<ProjectFullTable> result = employeeDao.employeeAssignedProjects(userId);

        // Assert
        // Add assertions as needed
    }

    @Test
    public void testUpdateProjectStatus() {
        // Arrange
        EmployeeDao employeeDao = mock(EmployeeDao.class);
        String projectStatus = "InProgress";
        String projectId = "P123";

        // Act
        employeeDao.updateProjectStatus(projectStatus, projectId);

        // Assert
        // Add assertions as needed
    }

    @Test
    public void testUpdateProjectIssues() {
        // Arrange
        EmployeeDao employeeDao = mock(EmployeeDao.class);
        String projectIssues = "Issue description";
        String projectId = "P123";

        // Act
        employeeDao.updateProjectIssues(projectIssues, projectId);

        // Assert
        // Add assertions as needed
    }

    @Test
    public void testTeamMembers() {
        // Arrange
        EmployeeDao employeeDao = mock(EmployeeDao.class);
        int userId = 123;

        // Act
        List<TeamMembersDetails> result = employeeDao.teamMembers(userId);

        // Assert
        // Add assertions as needed
    }
}
