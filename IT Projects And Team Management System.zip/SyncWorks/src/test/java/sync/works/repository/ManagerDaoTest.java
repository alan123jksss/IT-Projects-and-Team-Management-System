package sync.works.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ManagerDaoTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
