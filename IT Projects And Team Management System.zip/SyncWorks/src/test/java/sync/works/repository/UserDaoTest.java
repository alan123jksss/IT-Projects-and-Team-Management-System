package sync.works.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.springframework.dao.EmptyResultDataAccessException;
import sync.works.entities.UserLoginDetails;
import sync.works.entities.UserSignUpDetails;
import sync.works.repository.UserDao;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class UserDaoTest {

 // Import Mockito's argument matchers

	@Test
	public void testRegisterUser() {
	    // Mock UserDao
	    UserDao userDao = mock(UserDao.class);

	    // Stubbing the registerUser method using Mockito's any() matcher
	    when(userDao.registerUser(any(UserSignUpDetails.class))).thenReturn(1);

	    // Testing the method
	    int result = userDao.registerUser(new UserSignUpDetails());
	    assertEquals(1, result);
	}

    @Test
    public void testGetLoginDetails() {
        // Mock UserDao
        UserDao userDao = mock(UserDao.class);

        // Create expected UserLoginDetails object
        UserLoginDetails expected = new UserLoginDetails();
        // Initialize expected object with appropriate values
        // For example:
        expected.setUserId(1);
        expected.setFirstName("John");
        expected.setLastName("Doe");
        // Set other properties as needed

        // Stubbing the getLoginDetails method
        when(userDao.getLoginDetails("username")).thenReturn(expected);

        // Testing the method
        UserLoginDetails result = userDao.getLoginDetails("username");
        assertEquals(expected, result);
    }

  

    

    @Test
    public void testGetSecurityDetails() {
        // Mock UserDao
        UserDao userDao = mock(UserDao.class);

        // Stubbing the getSecurityDetails method to return any instance of UserSignUpDetails
        when(userDao.getSecurityDetails("employeeId")).thenReturn(new UserSignUpDetails());

        // Testing the method
        UserSignUpDetails result = userDao.getSecurityDetails("employeeId");
        assertNotNull(result); // Check that result is not null
    }



    @Test
    public void testUpdatePassword() {
        // Mock UserDao
        UserDao userDao = mock(UserDao.class);

        // Testing the method
        userDao.updatePassword("emailId", "newPassword");
        // No assertion here, as we are testing void method
    }

    @Test
    public void testGetOneUser() {
        // Mock UserDao
        UserDao userDao = mock(UserDao.class);

        // Create expected UserLoginDetails object
        UserLoginDetails expected = new UserLoginDetails();
        // Set up expected object with appropriate values
        // For example:
        expected.setUserId(1);
        expected.setFirstName("John");
        expected.setLastName("Doe");
        // Set other properties as needed

        // Stubbing the getOneUser method
        when(userDao.getOneUser("employeeId")).thenReturn(expected);

        // Testing the method
        UserLoginDetails result = userDao.getOneUser("employeeId");
        assertEquals(expected, result);
    }

}
