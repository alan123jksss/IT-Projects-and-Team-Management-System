package sync.works.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamMembersDetails;
import sync.works.repository.EmployeeDaoImpl;
import sync.works.row_mappers.EmployeeAssignProjectsRowMapper;
import sync.works.row_mappers.EmployeeAssignedManagerRowMapper;
import sync.works.row_mappers.TeamMemberRowMapper;
import sync.works.row_mappers.TeamMemberRowMapper;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;


import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

public class EmployeeDaoImplTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private EmployeeDaoImpl employeeDao;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testManagerAssigned() {
        // Arrange
        String domain = "example.com";
        List<ListOfUsers> expectedList = new ArrayList<>();
        // Add expectedList setup

        when(jdbcTemplate.query(anyString(), any(EmployeeAssignedManagerRowMapper.class), eq(domain)))
                .thenReturn(expectedList);

        // Act
        List<ListOfUsers> actualList = employeeDao.managerAssigned(domain);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testEmployeeAssignedProjects() {
        // Arrange
        int userId = 123;
        List<ProjectFullTable> expectedList = new ArrayList<>();
        // Add expectedList setup

        when(jdbcTemplate.query(anyString(), any(EmployeeAssignProjectsRowMapper.class), eq(userId)))
                .thenReturn(expectedList);

        // Act
        List<ProjectFullTable> actualList = employeeDao.employeeAssignedProjects(userId);

        // Assert
        assertEquals(expectedList, actualList);
    }

    @Test
    public void testUpdateProjectStatus() {
        // Arrange
        String projectStatus = "InProgress";
        String projectId = "P123";

        // Act
        employeeDao.updateProjectStatus(projectStatus, projectId);

        // Assert
        // Add assertions as needed
    }

    @Test
    public void testUpdateProjectIssues() {
        // Arrange
        String projectIssues = "Issue description";
        String projectId = "P123";

        // Act
        employeeDao.updateProjectIssues(projectIssues, projectId);

        // Assert
        // Add assertions as needed
    }

    @Test
    public void testTeamMembers() {
        // Arrange
        int userId = 123;
        List<TeamMembersDetails> expectedList = new ArrayList<>();
        // Add expectedList setup

        when(jdbcTemplate.query(anyString(), any(TeamMemberRowMapper.class), eq(userId)))
                .thenReturn(expectedList);

        // Act
        List<TeamMembersDetails> actualList = employeeDao.teamMembers(userId);

        // Assert
        assertEquals(expectedList, actualList);
    }

}
