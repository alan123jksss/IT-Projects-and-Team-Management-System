package sync.works.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.UserSignUpDetails;
import sync.works.repository.AdminDao;
import sync.works.repository.AdminDaoImpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class AdminDaoTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private AdminDaoImpl adminDao;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDeleteManagers() {
        // Arrange
        String employeeId = "E123";
        int expectedCount = 1;

        when(jdbcTemplate.update(anyString(), eq(employeeId))).thenReturn(expectedCount);

        // Act
        int actualCount = adminDao.deleteManagers(employeeId);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testUpdateManagers() {
        // Arrange
        String employeeId = "E123";
        boolean status = true;
        int expectedCount = 1;

        when(jdbcTemplate.update(anyString(), eq(status), eq(employeeId))).thenReturn(expectedCount);

        // Act
        int actualCount = adminDao.updateManagers(employeeId, status);

        // Assert
        assertEquals(expectedCount, actualCount);
    }

    // Similar tests for other methods...

}
