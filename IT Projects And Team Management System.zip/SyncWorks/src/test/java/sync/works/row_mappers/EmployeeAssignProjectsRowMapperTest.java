package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sync.works.entities.ProjectFullTable;

public class EmployeeAssignProjectsRowMapperTest {

    private EmployeeAssignProjectsRowMapper rowMapper;

    @BeforeEach
    public void setUp() {
        rowMapper = new EmployeeAssignProjectsRowMapper();
    }

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("ProjectId")).thenReturn(1);
        when(resultSet.getString("ProjectName")).thenReturn("Project X");
        when(resultSet.getString("ProjectRequirement")).thenReturn("Requirement details");
        when(resultSet.getString("ProjectPriority")).thenReturn("High");
        when(resultSet.getString("ProjectAssignDate")).thenReturn("2024-02-17");
        when(resultSet.getString("ProjectEndDate")).thenReturn("2024-03-17");
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("teamName")).thenReturn("Team Alpha");
        when(resultSet.getString("projectStatus")).thenReturn("In Progress");
        when(resultSet.getString("issues")).thenReturn("None");

        // Call the method to test
        ProjectFullTable project = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, project.getProjId());
        assertEquals("Project X", project.getProjName());
        assertEquals("Requirement details", project.getProjRequirement());
        assertEquals("High", project.getProjPriority());
        assertEquals("2024-02-17", project.getProjAssignDate());
        assertEquals("2024-03-17", project.getProjEndDate());
        assertEquals("John", project.getManagerName());
        assertEquals("Team Alpha", project.getProjTeamName());
        assertEquals("In Progress", project.getProjStatus());
        assertEquals("None", project.getProjIssues());
        // Add assertions for other properties if needed
    }
}
