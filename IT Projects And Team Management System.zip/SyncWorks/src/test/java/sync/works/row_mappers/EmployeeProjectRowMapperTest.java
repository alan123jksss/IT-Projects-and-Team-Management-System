package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sync.works.entities.EmployeeProjectDetails;

public class EmployeeProjectRowMapperTest {

    private EmployeeProjectRowMapper rowMapper;

    @BeforeEach
    public void setUp() {
        rowMapper = new EmployeeProjectRowMapper();
    }

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("ProjectId")).thenReturn(1);
        when(resultSet.getString("ProjectName")).thenReturn("Project X");
        when(resultSet.getString("ProjectRequirement")).thenReturn("Requirement details");
        when(resultSet.getString("ProjectPriority")).thenReturn("High");
        when(resultSet.getString("ProjectAssignDate")).thenReturn("2024-02-17");
        when(resultSet.getString("ProjectEndDate")).thenReturn("2024-03-17");
        when(resultSet.getInt("userId")).thenReturn(101);
        when(resultSet.getInt("teamId")).thenReturn(201);
        when(resultSet.getString("teamName")).thenReturn("Team Alpha");

        // Call the method to test
        EmployeeProjectDetails details = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, details.getProjId());
        assertEquals("Project X", details.getProjName());
        assertEquals("Requirement details", details.getProjRequirement());
        assertEquals("High", details.getProjPriority());
        assertEquals("2024-02-17", details.getProjAssignDate());
        assertEquals("2024-03-17", details.getProjEndDate());
        assertEquals(101, details.getUserId());
        assertEquals(201, details.getTeamId());
        assertEquals("Team Alpha", details.getTeamName());
        // Add assertions for other properties if needed
    }
}
