package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sync.works.entities.ListOfUsers;

public class ListOfUsersRowMapperTest {

    private ListOfUsersRowMapper rowMapper;

    @BeforeEach
    public void setUp() {
        rowMapper = new ListOfUsersRowMapper();
    }

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("userId")).thenReturn(1);
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("lastName")).thenReturn("Doe");
        when(resultSet.getString("employeeId")).thenReturn("EMP001");
        when(resultSet.getString("role")).thenReturn("Manager");
        when(resultSet.getString("domain")).thenReturn("IT");
        when(resultSet.getBoolean("status")).thenReturn(true);

        // Call the method to test
        ListOfUsers listOfUsers = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, listOfUsers.getId());
        assertEquals("John", listOfUsers.getFirstName());
        assertEquals("Doe", listOfUsers.getLastName());
        assertEquals("EMP001", listOfUsers.getEmployeeId());
        assertEquals("Manager", listOfUsers.getRole());
        assertEquals("IT", listOfUsers.getDomain());
        assertEquals(true, listOfUsers.isStatus());
    }
}
