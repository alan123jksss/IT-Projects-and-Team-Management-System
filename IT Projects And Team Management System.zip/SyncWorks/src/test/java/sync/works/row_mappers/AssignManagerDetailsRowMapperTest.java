package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sync.works.entities.UserSignUpDetails;

public class AssignManagerDetailsRowMapperTest {

    private AssignManagerDetailsRowMapper rowMapper;

    @BeforeEach
    public void setUp() {
        rowMapper = new AssignManagerDetailsRowMapper();
    }

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("employeeId")).thenReturn("EMP001");

        // Call the method to test
        UserSignUpDetails userDetails = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals("John", userDetails.getFirstName());
        assertEquals("EMP001", userDetails.getEmployeeId());
        // Add assertions for other properties if needed
    }
}
