package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.ProjectEntities;
import sync.works.row_mappers.ManagerAssignedProjectsRowMapper;

public class ManagerAssignedProjectsRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Arrange
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("ProjectId")).thenReturn(1);
        when(resultSet.getString("ProjectName")).thenReturn("Project A");
        when(resultSet.getString("ProjectRequirement")).thenReturn("Requirement A");
        when(resultSet.getString("ProjectPriority")).thenReturn("High");
        when(resultSet.getString("ProjectAssignDate")).thenReturn("2024-01-01");
        when(resultSet.getString("ProjectEndDate")).thenReturn("2024-02-01");
        when(resultSet.getString("ProjectStatuss")).thenReturn("Open");
        when(resultSet.getString("ProjectIssues")).thenReturn("No issues");
        when(resultSet.getString("ProjectTeamName")).thenReturn("Team A");

        ManagerAssignedProjectsRowMapper mapper = new ManagerAssignedProjectsRowMapper();

        // Act
        ProjectEntities project = mapper.mapRow(resultSet, 1);

        // Assert
        assertEquals(1, project.getProjId());
        assertEquals("Project A", project.getProjName());
        assertEquals("Requirement A", project.getProjRequirement());
        assertEquals("High", project.getProjPriority());
        assertEquals("2024-01-01", project.getProjAssignDate());
        assertEquals("2024-02-01", project.getProjEndDate());
        assertEquals("Open", project.getProjStatus());
        assertEquals("No issues", project.getProjIssues());
        assertEquals("Team A", project.getProjTeamName());
    }
}
