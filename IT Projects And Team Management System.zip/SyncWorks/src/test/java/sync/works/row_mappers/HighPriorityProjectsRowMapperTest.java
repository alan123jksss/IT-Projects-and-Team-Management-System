package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sync.works.entities.ProjectEntities;

public class HighPriorityProjectsRowMapperTest {

    private HighPriorityProjectsRowMapper rowMapper;

    @BeforeEach
    public void setUp() {
        rowMapper = new HighPriorityProjectsRowMapper();
    }

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getInt("ProjectId")).thenReturn(1);
        when(resultSet.getString("ProjectName")).thenReturn("Project X");
        when(resultSet.getString("ProjectAssignDate")).thenReturn("2024-02-17");
        when(resultSet.getString("ProjectEndDate")).thenReturn("2024-03-17");

        // Call the method to test
        ProjectEntities project = rowMapper.mapRow(resultSet, 1);

        // Assertions
        assertEquals(1, project.getProjId());
        assertEquals("Project X", project.getProjName());
        assertEquals("2024-02-17", project.getProjAssignDate());
        assertEquals("2024-03-17", project.getProjEndDate());
        // Add assertions for other properties if needed
    }
}
