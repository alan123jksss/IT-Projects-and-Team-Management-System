package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import sync.works.entities.ManagerSelectedTeams;
import sync.works.row_mappers.ManagerSelectedTeamsRowMapper;

public class ManagerSelectedTeamsRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Arrange
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getString("teamName")).thenReturn("Team A");
        when(resultSet.getString("firstName")).thenReturn("John");
        when(resultSet.getString("employeeId")).thenReturn("E123");
        when(resultSet.getString("ProjectName")).thenReturn("Project X");

        ManagerSelectedTeamsRowMapper mapper = new ManagerSelectedTeamsRowMapper();

        // Act
        ManagerSelectedTeams teams = mapper.mapRow(resultSet, 1);

        // Assert
        assertEquals("Team A", teams.getTeamName());
        assertEquals("John", teams.getFirstName());
        assertEquals("E123", teams.getEmployeeId());
        assertEquals("Project X", teams.getProjectName());
    }
}
