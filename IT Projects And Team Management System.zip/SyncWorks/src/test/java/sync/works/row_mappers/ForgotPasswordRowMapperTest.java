package sync.works.row_mappers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.RowMapper;
import sync.works.entities.UserSignUpDetails;

public class ForgotPasswordRowMapperTest {

    @Test
    public void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("securityQuestion")).thenReturn("What is your favorite color?");
        when(rs.getString("answer")).thenReturn("Blue");

        // Create instance of ForgotPasswordRowMapper
        RowMapper<UserSignUpDetails> rowMapper = new ForgotPasswordRowMapper();

        // Call mapRow method and get the result
        UserSignUpDetails result = rowMapper.mapRow(rs, 1);

        // Assertions
        assertEquals("What is your favorite color?", result.getSecurityQuestion());
        assertEquals("Blue", result.getAnswer());
    }
}
