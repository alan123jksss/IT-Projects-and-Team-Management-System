package sync.works.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamMembersDetails;
import sync.works.entities.UserLoginDetails;
import sync.works.repository.EmployeeDao;
import sync.works.repository.UserDao;

@Controller
public class EmployeeController {
	
	@Autowired                    
	EmployeeDao employeeDao;
	
	@Autowired
	UserDao userDao;
	
	@GetMapping("/employeeDashboard")
	public String employeeDashboard(Model model) {
		
		List<ProjectFullTable> employeeAssignedProjects = employeeDao.employeeAssignedProjects(SyncWorksController.userId);
		model.addAttribute("employeeAssignedProjects",employeeAssignedProjects);
		
		return "employee_dashboard";
	}

	@GetMapping("/assignedManager")
	public String assignedManagers( Model model) {

		String destination ="";	
		
		List<ListOfUsers> assignedManager = employeeDao.managerAssigned(SyncWorksController.domain);
		model.addAttribute("assignedManager",assignedManager);
		 
		destination = "employee_manager_dashboard";
		
		return destination;	
	}
	
	@GetMapping("/employeeAssignedProjects")
	public String employeeAssignedProjects(Model model , UserLoginDetails userLoginDetails) {		
		
		employeeDao.employeeAssignedProjects(SyncWorksController.userId);
		
		return "admin_employee_dashboard";
	}
	
	/*
	 * @GetMapping("/viewTeamMembers") public String viewTeamMembers(Model model,
	 * UserLoginDetails userLoginDetails) {
	 * 
	 * userLoginDetails=userDao.getLoginDetails(userLoginDetails.getEmployeeId());
	 * 
	 * List<EmployeeProjectDetails> viewTeamMembers =
	 * employeeDao.teamMembers(userLoginDetails.getDomain());
	 * model.addAttribute("viewTeamMembers", viewTeamMembers);
	 * 
	 * return "admin_employee_dashboard";
	 * 
	 * }
	 */
	
	@GetMapping("managerAssigned")
	public String managerAssigned(Model model, UserLoginDetails userLoginDetails) {
		
		userLoginDetails=userDao.getLoginDetails(userLoginDetails.getEmployeeId());
		
		List<ListOfUsers> managerAssigned = employeeDao.managerAssigned(SyncWorksController.domain);
		model.addAttribute("managerAssigned", managerAssigned);
			
		return "employee_dashboard";
	}
	
	@PostMapping("/updateProjectStatus")
	public String updateProjectStatus(Model model,UserLoginDetails userLoginDetails, @RequestParam("projectStatus") String projectStatus,
			@RequestParam("projectId") String projectId) {
				
		System.out.println(projectStatus);
		System.out.println(projectId);
		
		employeeDao.updateProjectStatus(projectStatus,projectId);	
		
		List<ProjectFullTable> employeeAssignedProjects = employeeDao.employeeAssignedProjects(userLoginDetails.getUserId());
		model.addAttribute("employeeAssignedProjects",employeeAssignedProjects);
						
		return "employee_dashboard";
		
	}
	
	@GetMapping("/updateProjectIssues")
	public String updateProjectIssues(Model model,
			@RequestParam("projectIssues") String projectIssues,
			@RequestParam("projectId") String projectId) {
		
		
		System.out.println(projectIssues);
		System.out.println(projectId);
		
		employeeDao.updateProjectIssues(projectIssues,projectId);
		
//		List<ProjectFullTable> employeeAssignedProjects =employeeDao.employeeAssignedProjects(userLoginDetails.getDomain());
//		model.addAttribute("employeeAssignedProjects",employeeAssignedProjects);
//		
		
		return "employee_dashboard";
		
	}
	
	@GetMapping("/teamMembers")
	public String teamMembers(Model model) {
		
		
		System.out.println("sample id" + SyncWorksController.userId);
		List<TeamMembersDetails>  teamMembers = employeeDao.teamMembers(SyncWorksController.userId);
		model.addAttribute("teamMembers", teamMembers);
		
		return "employee_team_member_details";
		
	}
	
	
	
	
	
}
