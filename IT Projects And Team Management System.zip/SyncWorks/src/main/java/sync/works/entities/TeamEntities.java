package sync.works.entities;

public class TeamEntities {
	
	private String firstName;
	private String lastName;
	private String employeeId;
	private int role;
	private String domain;
	private int teamId;
	private String teamName;
	private int userId;
	private int projectId;
	
	
	
	public TeamEntities() {
		super();
	}



	public TeamEntities(String firstName, String lastName, String employeeId, int role, String domain, int teamId,
			String teamName, int userId, int projectId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.role = role;
		this.domain = domain;
		this.teamId = teamId;
		this.teamName = teamName;
		this.userId = userId;
		this.projectId = projectId;
	}



	public TeamEntities(String firstName, String lastName, String employeeId, int role, String domain, int teamId,
			String teamName, int projectId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.role = role;
		this.domain = domain;
		this.teamId = teamId;
		this.teamName = teamName;
		this.projectId = projectId;
	}
    


	public TeamEntities(int teamId, String teamName, int userId, int projectId) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		this.userId = userId;
		this.projectId = projectId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}



	public int getRole() {
		return role;
	}



	public void setRole(int role) {
		this.role = role;
	}



	public String getDomain() {
		return domain;
	}



	public void setDomain(String domain) {
		this.domain = domain;
	}



	public int getTeamId() {
		return teamId;
	}



	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}



	public String getTeamName() {
		return teamName;
	}



	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public int getProjectId() {
		return projectId;
	}



	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}



	@Override
	public String toString() {
		return "TeamEntities [firstName=" + firstName + ", lastName=" + lastName + ", employeeId=" + employeeId
				+ ", role=" + role + ", domain=" + domain + ", teamId=" + teamId + ", teamName=" + teamName
				+ ", userId=" + userId + ", projectId=" + projectId + "]";
	}


	
	

}
