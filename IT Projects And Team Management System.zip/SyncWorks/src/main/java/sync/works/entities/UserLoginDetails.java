package sync.works.entities;

public class UserLoginDetails {
	private int userId;
	private String firstName;
	private String lastName;
	private String employeeId;
	private String password;
	private int    role;
	private String domain;
	private boolean status;
	private String pwdSalt;
	private String pwdHash;
	public UserLoginDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserLoginDetails(String firstName, String lastName, String employeeId, String password, int role,
			String domain, boolean status, String pwdSalt, String pwdHash) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.password = password;
		this.role = role;
		this.domain = domain;
		this.status = status;
		this.pwdSalt = pwdSalt;
		this.pwdHash = pwdHash;
	}
	public UserLoginDetails(int userId, String firstName, String lastName, String employeeId, String password, int role,
			String domain, boolean status, String pwdSalt, String pwdHash) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
		this.password = password;
		this.role = role;
		this.domain = domain;
		this.status = status;
		this.pwdSalt = pwdSalt;
		this.pwdHash = pwdHash;
	}
	public UserLoginDetails(String firstName, String lastName, String password, int role, String domain, boolean status,
			String pwdSalt, String pwdHash) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.role = role;
		this.domain = domain;
		this.status = status;
		this.pwdSalt = pwdSalt;
		this.pwdHash = pwdHash;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getPwdSalt() {
		return pwdSalt;
	}
	public void setPwdSalt(String pwdSalt) {
		this.pwdSalt = pwdSalt;
	}
	public String getPwdHash() {
		return pwdHash;
	}
	public void setPwdHash(String pwdHash) {
		this.pwdHash = pwdHash;
	}
	@Override
	public String toString() {
		return "UserLoginDetails [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", employeeId=" + employeeId + ", password=" + password + ", role=" + role + ", domain=" + domain
				+ ", status=" + status + ", pwdSalt=" + pwdSalt + ", pwdHash=" + pwdHash + "]";
	}
	
}
