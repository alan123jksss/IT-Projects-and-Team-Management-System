package sync.works.entities;

public class EmployeeProjectDetails {
	private int    projId;
	private String projName;
	private String projRequirement;
	private String projPriority;
	private String projAssignDate;
	private String projEndDate;
	private int teamId;
	private String teamName;
	private int userId;
	public EmployeeProjectDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeProjectDetails(String projName, String projRequirement, String projPriority, String projAssignDate,
			String projEndDate, String teamName, int userId) {
		super();
		this.projName = projName;
		this.projRequirement = projRequirement;
		this.projPriority = projPriority;
		this.projAssignDate = projAssignDate;
		this.projEndDate = projEndDate;
		this.teamName = teamName;
		this.userId = userId;
	}
	public EmployeeProjectDetails(int projId, String projName, String projRequirement, String projPriority,
			String projAssignDate, String projEndDate, int teamId, String teamName, int userId) {
		super();
		this.projId = projId;
		this.projName = projName;
		this.projRequirement = projRequirement;
		this.projPriority = projPriority;
		this.projAssignDate = projAssignDate;
		this.projEndDate = projEndDate;
		this.teamId = teamId;
		this.teamName = teamName;
		this.userId = userId;
	}
	public int getProjId() {
		return projId;
	}
	public void setProjId(int projId) {
		this.projId = projId;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
	public String getProjRequirement() {
		return projRequirement;
	}
	public void setProjRequirement(String projRequirement) {
		this.projRequirement = projRequirement;
	}
	public String getProjPriority() {
		return projPriority;
	}
	public void setProjPriority(String projPriority) {
		this.projPriority = projPriority;
	}
	public String getProjAssignDate() {
		return projAssignDate;
	}
	public void setProjAssignDate(String projAssignDate) {
		this.projAssignDate = projAssignDate;
	}
	public String getProjEndDate() {
		return projEndDate;
	}
	public void setProjEndDate(String projEndDate) {
		this.projEndDate = projEndDate;
	}
	public int getTeamId() {
		return teamId;
	}
	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "EmployeeProjectDetails [projId=" + projId + ", projName=" + projName + ", projRequirement="
				+ projRequirement + ", projPriority=" + projPriority + ", projAssignDate=" + projAssignDate
				+ ", projEndDate=" + projEndDate + ", teamId=" + teamId + ", teamName=" + teamName + ", userId="
				+ userId + "]";
	}
	
}
