package sync.works.entities;

public class ProjectFullTable {
	
	private int    projId;
	private String projName;
	private String projRequirement;
	private String projPriority;
	private String projAssignDate;
	private String projEndDate;
	private String projTeamName;
	private String projStatus;
	private String projIssues;
	private String managerName;
	private String managerEmployeeId;
	
	public ProjectFullTable() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProjectFullTable(int projId, String projName, String projRequirement, String projPriority,
			String projAssignDate, String projEndDate, String projTeamName, String projStatus, String projIssues,
			String managerName, String managerEmployeeId) {
		super();
		this.projId = projId;
		this.projName = projName;
		this.projRequirement = projRequirement;
		this.projPriority = projPriority;
		this.projAssignDate = projAssignDate;
		this.projEndDate = projEndDate;
		this.projTeamName = projTeamName;
		this.projStatus = projStatus;
		this.projIssues = projIssues;
		this.managerName = managerName;
		this.managerEmployeeId = managerEmployeeId;
	}

	public ProjectFullTable(String projName, String projRequirement, String projPriority, String projAssignDate,
			String projEndDate, String projTeamName, String projStatus, String projIssues, String managerName,
			String managerEmployeeId) {
		super();
		this.projName = projName;
		this.projRequirement = projRequirement;
		this.projPriority = projPriority;
		this.projAssignDate = projAssignDate;
		this.projEndDate = projEndDate;
		this.projTeamName = projTeamName;
		this.projStatus = projStatus;
		this.projIssues = projIssues;
		this.managerName = managerName;
		this.managerEmployeeId = managerEmployeeId;
	}

	public int getProjId() {
		return projId;
	}

	public void setProjId(int projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public String getProjRequirement() {
		return projRequirement;
	}

	public void setProjRequirement(String projRequirement) {
		this.projRequirement = projRequirement;
	}

	public String getProjPriority() {
		return projPriority;
	}

	public void setProjPriority(String projPriority) {
		this.projPriority = projPriority;
	}

	public String getProjAssignDate() {
		return projAssignDate;
	}

	public void setProjAssignDate(String projAssignDate) {
		this.projAssignDate = projAssignDate;
	}

	public String getProjEndDate() {
		return projEndDate;
	}

	public void setProjEndDate(String projEndDate) {
		this.projEndDate = projEndDate;
	}

	public String getProjTeamName() {
		return projTeamName;
	}

	public void setProjTeamName(String projTeamName) {
		this.projTeamName = projTeamName;
	}

	public String getProjStatus() {
		return projStatus;
	}

	public void setProjStatus(String projStatus) {
		this.projStatus = projStatus;
	}

	public String getProjIssues() {
		return projIssues;
	}

	public void setProjIssues(String projIssues) {
		this.projIssues = projIssues;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getManagerEmployeeId() {
		return managerEmployeeId;
	}

	public void setManagerEmployeeId(String managerEmployeeId) {
		this.managerEmployeeId = managerEmployeeId;
	}

	@Override
	public String toString() {
		return "ProjectFullTable [projId=" + projId + ", projName=" + projName + ", projRequirement=" + projRequirement
				+ ", projPriority=" + projPriority + ", projAssignDate=" + projAssignDate + ", projEndDate="
				+ projEndDate + ", projTeamName=" + projTeamName + ", projStatus=" + projStatus + ", projIssues=" + projIssues
				+ ", managerName=" + managerName + ", managerEmployeeId=" + managerEmployeeId + "]";
	}

	
}
