package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import sync.works.entities.UserSignUpDetails;


public class UserSignUpDetailsRowMapper implements RowMapper<UserSignUpDetails> {

	@Override
	public UserSignUpDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		UserSignUpDetails listOfUser = new UserSignUpDetails();
		
		//listOfUser.setUserId(rs.getInt("userId"));
		listOfUser.setFirstName(rs.getString("firstName"));		
		listOfUser.setLastName(rs.getString("lastName"));
		listOfUser.setEmployeeId(rs.getString("employeeId"));
		//listOfUser.setDomain(rs.getString("domain"));
		listOfUser.setMobileNo(rs.getString("mobileNo"));
		listOfUser.setGender(rs.getString("gender"));
		//listOfUser.setRole(rs.getInt("role"));
		//listOfUser.setStatus(rs.getBoolean("status"));

		return listOfUser;
	
	}

}
