package sync.works.row_mappers;

import java.sql.ResultSet;


import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ProjectFullTable;
import sync.works.entities.UserSignUpDetails;


public class TeamNameCreationRowMapper implements RowMapper<ProjectFullTable> {

	@Override
	public ProjectFullTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ProjectFullTable listOfFullProjTable = new ProjectFullTable();
		
		listOfFullProjTable.setProjId(rs.getInt("ProjectId"));
		listOfFullProjTable.setProjName(rs.getString("ProjectName"));
		listOfFullProjTable.setProjTeamName(rs.getString("ProjectTeamName"));
		

	
		return listOfFullProjTable;
	}

}
