package sync.works.row_mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.UserLoginDetails;



public class LoginRowMapper implements RowMapper<UserLoginDetails> {

	@Override
	public UserLoginDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		UserLoginDetails login = new UserLoginDetails();
		
		int userId =rs.getInt("userId");
		String employeeId = rs.getString("employeeId");
		String firstName = rs.getString("firstName");
		String lastName = rs.getString("lastName");
		String domain = rs.getString("domain");
		int role = rs.getInt("role");
		boolean status = rs.getBoolean("status");
		String pwdSalt = rs.getString("pwdSalt");
		String pwdHash = rs.getString("pwdHash");
		
		
		login.setUserId(userId);
		login.setFirstName(employeeId);
		login.setFirstName(firstName);
		login.setLastName(lastName);
		login.setDomain(domain);
		login.setRole(role);
		login.setStatus(status);
		login.setPwdSalt(pwdSalt);
		login.setPwdHash(pwdHash);
		
		return login;
	}

}
