package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.UserSignUpDetails;

public class ForgotPasswordRowMapper implements RowMapper<UserSignUpDetails> {

	@Override
	public UserSignUpDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		UserSignUpDetails user = new UserSignUpDetails();
		
		String securityQuestion = rs.getString("securityQuestion");
		String securityAnswer = rs.getString("answer");
		
		user.setSecurityQuestion(securityQuestion);
		user.setAnswer(securityAnswer);
		
		return user;
		
		
	
		
	}

}
