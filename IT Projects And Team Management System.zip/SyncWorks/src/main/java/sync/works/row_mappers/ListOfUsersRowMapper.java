package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.ListOfUsers;


public class ListOfUsersRowMapper implements RowMapper<ListOfUsers> {

	@Override
	public ListOfUsers mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ListOfUsers listOfManagers = new ListOfUsers();
	
		listOfManagers.setId(rs.getInt("userId"));
		listOfManagers.setFirstName(rs.getString("firstName"));
		listOfManagers.setLastName(rs.getString("lastName"));
		listOfManagers.setEmployeeId(rs.getString("employeeId"));
		listOfManagers.setRole(rs.getString("role"));
		listOfManagers.setDomain(rs.getString("domain"));
		listOfManagers.setStatus(rs.getBoolean("status"));
		return listOfManagers;
	
	}

}
