package sync.works.row_mappers;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sync.works.entities.TeamMembersDetails;

public class TeamMemberRowMapper implements RowMapper<TeamMembersDetails> {

	@Override
	public TeamMembersDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		TeamMembersDetails teamMembersDetails = new TeamMembersDetails();
		
		teamMembersDetails.setUserId(rs.getInt("userId"));
		teamMembersDetails.setFirstName(rs.getString("firstName"));
		teamMembersDetails.setLastName(rs.getString("lastName"));
		teamMembersDetails.setEmployeeId(rs.getString("employeeId"));
		teamMembersDetails.setRole(rs.getInt("role"));
		teamMembersDetails.setDomain(rs.getString("domain"));
		teamMembersDetails.setGender(rs.getString("gender"));
		teamMembersDetails.setProjectName(rs.getString("ProjectName"));
		
		return teamMembersDetails;
	}

}
