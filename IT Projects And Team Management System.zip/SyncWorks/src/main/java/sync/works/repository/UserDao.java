package sync.works.repository;

import org.springframework.dao.EmptyResultDataAccessException;


import sync.works.entities.UserLoginDetails;
import sync.works.entities.UserSignUpDetails;

public interface UserDao {

	int registerUser(UserSignUpDetails user);

	UserLoginDetails getLoginDetails(String username) throws EmptyResultDataAccessException;

	UserSignUpDetails getSecurityDetails(String employeeId) throws EmptyResultDataAccessException;

	void updatePassword(String emailId, String newPassword);

	UserLoginDetails getOneUser(String employeeId);


	
}
