package sync.works.repository;

import java.util.List;


import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import sync.works.entities.EmployeeProjectDetails;
import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamMembersDetails;
import sync.works.row_mappers.EmployeeAssignProjectsRowMapper;
import sync.works.row_mappers.EmployeeAssignedManagerRowMapper;
import sync.works.row_mappers.EmployeeProjectRowMapper;
import sync.works.row_mappers.ListOfUsersRowMapper;
import sync.works.row_mappers.TeamMemberRowMapper;
import sync.works.utils.PasswordUtils;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	@Override
	public List<ListOfUsers> managerAssigned(String domain) {
		String GET_ASSIGNED_MANAGER = "SELECT * FROM user WHERE role = 2 AND domain = ?";
		return jdbcTemplate.query(GET_ASSIGNED_MANAGER, new EmployeeAssignedManagerRowMapper(),domain);
}
	
	
	@Override
	public List<ProjectFullTable> employeeAssignedProjects(int userId){
		String EMPLOYEE_ASSIGN_PROJECTS = "SELECT t.projectId, p.ProjectName,p.ProjectPriority,p.ProjectRequirement, p.ProjectAssignDate,"
				+ "p.ProjectEndDate, t.teamName, u.firstName, u.projectStatus, u.issues "
				+ "FROM team_table t JOIN user u ON t.userId = u.userId JOIN projects_table p "
				+ "ON t.projectId = p.ProjectId WHERE u.userId = ?";
		
		return jdbcTemplate.query(EMPLOYEE_ASSIGN_PROJECTS, new EmployeeAssignProjectsRowMapper(),userId);
	}
	
	 @Override
	    public void updateProjectStatus(String projectStatus, String projectId) {
	        String UPDATE_PROJECT_STATUS = "UPDATE projects_table AS pt JOIN team_table AS tt "
	        		+ "ON pt.ProjectId = tt.projectId JOIN user AS u ON tt.userId = u.userId "
	        		+ "SET pt.ProjectStatuss =?, u.projectStatus = ? WHERE pt.ProjectId = ?;";
	       
	        
	        jdbcTemplate.update(UPDATE_PROJECT_STATUS,projectStatus, projectStatus, projectId);
	    }
	 
	 @Override
	    public void updateProjectIssues(String projectIssues, String projectId) {
	        String UPDATE_PROJECT_ISSUES = "UPDATE projects_table AS pt JOIN team_table AS tt "
		        		+ "ON pt.ProjectId = tt.projectId JOIN user AS u ON tt.userId = u.userId SET "
		        		+ "pt.ProjectIssues = ?, u.issues = ? WHERE pt.ProjectId = ?;";
	       
	        
	        jdbcTemplate.update(UPDATE_PROJECT_ISSUES, projectIssues, projectIssues, projectId);
	    }
	 
	 @Override
		public List<TeamMembersDetails> teamMembers(int userId){
			String TEAM_MEMBERS = "SELECT t.userId,t.teamName, u.firstName, u.lastName, u.employeeId, u.role, u.domain, "
					+ "u.gender, t.projectId, p.ProjectName FROM team_table t JOIN user u "
					+ "ON t.userId = u.userId JOIN projects_table p "
					+ "ON t.projectId = p.ProjectId "
					+ "WHERE u.status=1 AND t.projectId IN ( SELECT projectId FROM team_table WHERE userId = ?);";
			
			return jdbcTemplate.query(TEAM_MEMBERS, new TeamMemberRowMapper(), userId );
		}
		

	}
	


