package sync.works.repository;

import java.util.List;


import sync.works.entities.ListOfUsers;
import sync.works.entities.ManagerSelectedTeams;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.TeamEntities;

public interface ManagerDao {

	int updateEmployee(String employeeId, boolean status);

	int deleteEmployee(String employeeId);

	List<ListOfUsers> getAllEmployees(int role, String domain);

	List<ListOfUsers> getApprovedEmployees(int role, String domain);

	List<ProjectEntities> getManagerProjects(String employeeId);

	int createTeam(TeamEntities teamEntities);

	List<TeamEntities> teamMembers(String domain);


	int updateTeamName(String teamName, int projectId);

	int totalManagerProjects(int userId);

	int totalManagerTeams(int managerId);

	int totalPendingProjects(int managerId);

	int totalProjectIssues(int managerId);

	int priorityHighProject(int managerId);

	int pendingEmployeeApproval(String domain);

	List<ProjectFullTable> teamNameCreation(int managerId);

	List<ManagerSelectedTeams> ManagerSelectedTeams(int managerId);


}
