package sync.works.repository;

import java.util.List;



import sync.works.entities.ListOfUsers;
import sync.works.entities.ProjectEntities;
import sync.works.entities.ProjectFullTable;
import sync.works.entities.UserSignUpDetails;

public interface AdminDao {

	int deleteManagers(String employeeId);

	int updateManagers(String employeeId, boolean status);

	List<ListOfUsers> getAllManagers(boolean status, int role);	
	
	int addProject(ProjectEntities projectEntities);
	
	int updateProject(ProjectEntities projectEntities);
	
	int deleteProject(int projectId);
	
	List<ProjectEntities> adminAllProjects();
	
	int totalOpenProjectsCount();
	
	int totalCloseProjectsCount();
	
	int totalManagerCount();
	
	int totalEmployeeCount();
	
	void assignManger(int userId, int ProjectId);

	List<UserSignUpDetails> showAssignManager();

	int getEmployeeId(String firstName);

	List<ListOfUsers> listOfApproveManagers();

	List<ProjectFullTable> projectFullTable();

	List<ListOfUsers> getAllManagers(int role);

	List<ProjectEntities> highPriorityProjects();

	List<UserSignUpDetails> adminProfile();

	int domainList(String domainName);

	List<String> domainNameList();

	List<ListOfUsers> getAllEmployees(int i);

	int totalProjectIssues();

	int highPriorityProjectsCount();

	int mediumPriorityProjectsCount();

	int LowPriorityProjectsCount();


	


}
